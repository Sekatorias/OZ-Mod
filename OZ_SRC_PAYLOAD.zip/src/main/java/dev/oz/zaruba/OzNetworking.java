package dev.oz.zaruba;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class OzNetworking {
    public static final Identifier OPEN_MENU = new Identifier(OzMod.MOD_ID, "open_menu");

    private OzNetworking() {}

    public static int openMenu(ServerCommandSource source, ZoneSearchManager zones) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("OZ GUI можно открыть только игроку."));
            return 0;
        }
        if (!ServerPlayNetworking.canSend(player, OPEN_MENU)) {
            source.sendError(Text.literal("OZ GUI недоступен: установи тот же OZ-мод на клиент."));
            return 0;
        }

        OzMenuState state = snapshot(source, zones);
        PacketByteBuf buf = PacketByteBufs.create();
        state.write(buf);
        ServerPlayNetworking.send(player, OPEN_MENU, buf);
        return 1;
    }

    private static OzMenuState snapshot(ServerCommandSource source, ZoneSearchManager zones) {
        var server = source.getServer();
        ServerPlayerEntity player = source.getPlayer();
        boolean admin = player != null && player.getCommandTags().contains("admin");

        return new OzMenuState(
                admin,
                zones.status(),
                score(server, "ozTeams", "OZ", 2),
                score(server, "ozBSize", "OZ", 1008),
                score(server, "ozSBStart", "OZ", 18),
                score(server, "ozSBSize", "OZ", 112),
                score(server, "ozSBDur", "OZ", 24),
                score(server, "ozMM", "OZ", 10),
                score(server, "ozEternal", "OZ", 0),
                score(server, "ozGlow", "OZ", 30),
                score(server, "ozGlowEnd", "OZ", 42),
                score(server, "ozCenterStart", "OZ", 18),
                score(server, "ozCenterEnd", "OZ", 42),
                score(server, "ozPressure", "OZ", 100),
                score(server, "ozKit", "OZ", 0),
                score(server, "ozEnabled", "OZMode", 1),
                score(server, "ozZone", "ZFilter", 0),
                score(server, "ozZone", "ZIndex", 0),
                enabled(server, "OZShrink", true),
                enabled(server, "OZEternal", false),
                enabled(server, "OZGlow", true),
                enabled(server, "OZMarkers", true),
                enabled(server, "OZPotions", true),
                enabled(server, "OZStew", true),
                enabled(server, "OZPassiveAI", true),
                enabled(server, "OZPhantoms", true),
                enabled(server, "OZJoining", true),
                enabled(server, "OZNightVision", false),
                enabled(server, "OZDiamondArmor", true),
                enabled(server, "OZFriendlyFire", false),
                enabled(server, "OZAdvancements", true),
                enabled(server, "OZConduit", true),
                enabled(server, "OZCenter", true)
        );
    }

    private static int score(net.minecraft.server.MinecraftServer server, String objective, String holder, int fallback) {
        return ScoreboardBridge.get(server, objective, holder, fallback);
    }

    private static boolean enabled(net.minecraft.server.MinecraftServer server, String holder, boolean fallback) {
        return ScoreboardBridge.get(server, "ozEnabled", holder, fallback ? 1 : 0) == 1;
    }
}

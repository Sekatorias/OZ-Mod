package dev.oz.zaruba.client;

import dev.oz.zaruba.OzMenuState;
import dev.oz.zaruba.OzNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class OzClient implements ClientModInitializer {
    private static KeyBinding openMenuKey;
    private static int refreshTicks = -1;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.oz.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "category.oz"
        ));

        ClientPlayNetworking.registerGlobalReceiver(OzNetworking.OPEN_MENU, (client, handler, buf, responseSender) -> {
            OzMenuState state = OzMenuState.read(buf);
            client.execute(() -> client.setScreen(new OzMenuScreen(state)));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendChatCommand("oz menu");
                }
            }

            if (refreshTicks >= 0 && --refreshTicks <= 0) {
                refreshTicks = -1;
                if (client.getNetworkHandler() != null && client.currentScreen instanceof OzMenuScreen) {
                    client.getNetworkHandler().sendChatCommand("oz menu");
                }
            }
        });
    }

    public static void scheduleRefresh() {
        refreshTicks = 5;
    }
}

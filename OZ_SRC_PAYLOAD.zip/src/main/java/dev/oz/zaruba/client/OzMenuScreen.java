package dev.oz.zaruba.client;

import dev.oz.zaruba.OzMenuState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class OzMenuScreen extends Screen {
    private enum Page { TEAMS, MATCH, ARENA, RULES, FINAL }

    private final OzMenuState state;
    private Page page = Page.ARENA;
    private int panelX;
    private int panelW;
    private int contentY;

    public OzMenuScreen(OzMenuState state) {
        super(Text.literal("OZ | Origins Zaruba"));
        this.state = state;
    }

    @Override
    protected void init() {
        panelW = Math.min(430, width - 20);
        panelX = (width - panelW) / 2;
        contentY = 70;
        addTabs();

        switch (page) {
            case TEAMS -> initTeams();
            case MATCH -> initMatch();
            case ARENA -> initArena();
            case RULES -> initRules();
            case FINAL -> initFinal();
        }
    }

    private void addTabs() {
        String[] names = {"Команды", "Матч", "Арена", "Правила", "Финал"};
        Page[] pages = Page.values();
        int gap = 3;
        int w = (panelW - gap * 4) / 5;
        for (int i = 0; i < pages.length; i++) {
            final Page target = pages[i];
            ButtonWidget b = ButtonWidget.builder(Text.literal(names[i]), btn -> {
                page = target;
                clearAndInit();
            }).dimensions(panelX + i * (w + gap), 43, w, 20).build();
            b.active = target != page;
            addDrawableChild(b);
        }
    }

    private void initTeams() {
        int x = panelX;
        int y = contentY;
        int gap = 4;
        int w = (panelW - gap * 2) / 3;

        addActionButton("Соло", x, y, w, 20, 1, false);
        addActionButton("Зритель", x + w + gap, y, w, 20, 2, false);
        addAdminButton("Перемешать", x + (w + gap) * 2, y, w, 20, 19);
        y += 25;

        String[] teams = {
                "Красные", "Жёлтые", "Зелёные", "Бирюзовые", "Синие", "Пурпурные", "Серые",
                "Бордовые", "Оранжевые", "Тёмно-зел.", "Призмарин", "Лазурит", "Хорус", "Чёрные"
        };
        for (int i = 0; i < teams.length; i++) {
            int col = i % 3;
            int row = i / 3;
            addActionButton(teams[i], x + col * (w + gap), y + row * 22, w, 20, 3 + i, false);
        }

        int controlsY = y + 5 * 22 + 4;
        addAdminButton("-", x, controlsY, 35, 20, 17);
        ButtonWidget teamCount = ButtonWidget.builder(Text.literal("Команд: " + state.teams()), btn -> {})
                .dimensions(x + 39, controlsY, panelW - 78, 20).build();
        teamCount.active = false;
        addDrawableChild(teamCount);
        addAdminButton("+", x + panelW - 35, controlsY, 35, 20, 18);
    }

    private void initMatch() {
        int x = panelX;
        int y = contentY;
        int third = (panelW - 8) / 3;

        addAdminButton(modeLabel("Стандарт", state.mode() == 1), x, y, third, 20, 31);
        addAdminButton(modeLabel("Выбывание", state.mode() == 2), x + third + 4, y, third, 20, 32);
        addAdminButton(modeLabel("Без регена", state.mode() == 3), x + (third + 4) * 2, y, third, 20, 33);
        y += 30;

        addAdminButton(kitLabel("Пусто", state.kit() == 0), x, y, third, 20, 208);
        addAdminButton(kitLabel("Дерево", state.kit() == 1), x + third + 4, y, third, 20, 209);
        addAdminButton(kitLabel("Камень", state.kit() == 2), x + (third + 4) * 2, y, third, 20, 210);
        y += 32;

        addValueRow("Метка минут", state.minuteMarker() + " мин", 100, 101, y);
        y += 27;
        addValueRow("Вечный день с", state.eternalStart() + " мин", 102, 103, y);
        y += 30;

        addAdminButton("СТАРТ МАТЧА", x, y, panelW, 24, 30);
    }

    private void initArena() {
        int y = contentY;
        addValueRow("Размер арены", Integer.toString(state.borderSize()), 20, 21, y);
        y += 25;
        addValueRow("Сужение с", state.shrinkStart() + " мин", 22, 23, y);
        y += 25;
        addValueRow("Финальный размер", Integer.toString(state.shrinkSize()), 24, 25, y);
        y += 25;
        addValueRow("Длительность", state.shrinkDuration() + " мин", 26, 27, y);
        y += 27;

        int half = (panelW - 4) / 2;
        addAdminButton(toggleLabel("Сужение", state.shrink()), panelX, y, half, 20, 29);
        addAdminButton("Предзагрузка", panelX + half + 4, y, half, 20, 28);
        y += 27;

        int q = (panelW - 12) / 4;
        String[] filters = {"Любая", "Вода", "Горы", "Микс"};
        for (int i = 0; i < 4; i++) {
            String label = (state.zoneFilter() == i ? "• " : "") + filters[i];
            addAdminButton(label, panelX + i * (q + 4), y, q, 20, 200 + i);
        }
        y += 27;
        addAdminButton("НАЙТИ НОВУЮ ЗОНУ", panelX, y, panelW, 24, 204);
    }

    private void initRules() {
        int x = panelX;
        int y = contentY;
        int gap = 4;
        int half = (panelW - gap) / 2;

        Toggle[] toggles = {
                new Toggle("Вечный день", state.eternal(), 106),
                new Toggle("Подсветка", state.glow(), 107),
                new Toggle("Маркеры", state.markers(), 108),
                new Toggle("Сильные зелья", state.potions(), 109),
                new Toggle("Подозр. рагу", state.stew(), 110),
                new Toggle("ИИ мирных", state.passiveAi(), 111),
                new Toggle("Фантомы", state.phantoms(), 112),
                new Toggle("Выбор команд", state.joining(), 113),
                new Toggle("Ночное зрение", state.nightVision(), 114),
                new Toggle("Алмазная броня", state.diamondArmor(), 115),
                new Toggle("Урон своим", state.friendlyFire(), 116),
                new Toggle("Ачивки", state.advancements(), 117),
                new Toggle("Conduit Power", state.conduit(), 118)
        };

        for (int i = 0; i < toggles.length; i++) {
            int col = i % 2;
            int row = i / 2;
            Toggle t = toggles[i];
            addAdminButton(toggleLabel(t.name(), t.enabled()), x + col * (half + gap), y + row * 23, half, 20, t.trigger());
        }
    }

    private void initFinal() {
        int y = contentY;
        addAdminButton(toggleLabel("Центр зоны", state.center()), panelX, y, panelW, 20, 119);
        y += 25;
        addValueRow("Центр: с", state.centerStart() + " мин", 120, 121, y);
        y += 25;
        addValueRow("Центр: до", state.centerEnd() + " мин", 122, 123, y);
        y += 25;
        addSyncRow("Центр", 124, 125, y);
        y += 29;

        addAdminButton(toggleLabel("Подсветка игроков", state.glow()), panelX, y, panelW, 20, 107);
        y += 25;
        addValueRow("Glow: с", state.glowStart() + " мин", 104, 105, y);
        y += 25;
        addValueRow("Glow: до", state.glowEnd() + " мин", 126, 127, y);
        y += 25;
        addSyncRow("Glow", 128, 129, y);
        y += 29;

        int third = (panelW - 8) / 3;
        addAdminButton(pressureLabel("Выкл", state.pressure() == 0), panelX, y, third, 20, 205);
        addAdminButton(pressureLabel("50%", state.pressure() == 50), panelX + third + 4, y, third, 20, 206);
        addAdminButton(pressureLabel("100%", state.pressure() == 100), panelX + (third + 4) * 2, y, third, 20, 207);
    }

    private void addValueRow(String name, String value, int minusTrigger, int plusTrigger, int y) {
        int side = 38;
        addAdminButton("-", panelX, y, side, 20, minusTrigger);
        ButtonWidget mid = ButtonWidget.builder(Text.literal(name + ": " + value), btn -> {})
                .dimensions(panelX + side + 4, y, panelW - side * 2 - 8, 20).build();
        mid.active = false;
        addDrawableChild(mid);
        addAdminButton("+", panelX + panelW - side, y, side, 20, plusTrigger);
    }

    private void addSyncRow(String name, int startTrigger, int endTrigger, int y) {
        int half = (panelW - 4) / 2;
        addAdminButton(name + " ← старт сужения", panelX, y, half, 20, startTrigger);
        addAdminButton(name + " ← конец сужения", panelX + half + 4, y, half, 20, endTrigger);
    }

    private ButtonWidget addAdminButton(String label, int x, int y, int w, int h, int trigger) {
        ButtonWidget b = addActionButton(label, x, y, w, h, trigger, true);
        b.active = state.admin();
        return b;
    }

    private ButtonWidget addActionButton(String label, int x, int y, int w, int h, int trigger, boolean adminOnly) {
        ButtonWidget b = ButtonWidget.builder(Text.literal(label), btn -> sendTrigger(trigger))
                .dimensions(x, y, w, h).build();
        if (adminOnly && !state.admin()) b.active = false;
        addDrawableChild(b);
        return b;
    }

    private void sendTrigger(int trigger) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() == null) return;
        client.getNetworkHandler().sendChatCommand("trigger ozOpt set " + trigger);
        OzClient.scheduleRefresh();
    }

    private static String toggleLabel(String name, boolean enabled) {
        return (enabled ? "[ВКЛ] " : "[ВЫКЛ] ") + name;
    }

    private static String modeLabel(String name, boolean selected) {
        return (selected ? "• " : "") + name;
    }

    private static String kitLabel(String name, boolean selected) {
        return (selected ? "• " : "") + "Кит: " + name;
    }

    private static String pressureLabel(String name, boolean selected) {
        return (selected ? "• " : "") + "Pressure " + name;
    }

    private String filterName() {
        return switch (state.zoneFilter()) {
            case 1 -> "Вода";
            case 2 -> "Горы";
            case 3 -> "Смешанная";
            default -> "Любая";
        };
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        int panelBottom = Math.min(height - 12, 230);
        context.fill(panelX - 6, 29, panelX + panelW + 6, panelBottom, 0xA0101018);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("OZ | ORIGINS ZARUBA").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                width / 2, 16, 0xFFFFFF);

        String role = state.admin() ? "Администратор OZ" : "Игрок";
        context.drawTextWithShadow(textRenderer, Text.literal(role).formatted(state.admin() ? Formatting.AQUA : Formatting.GRAY),
                panelX, 33, 0xFFFFFF);

        if (page == Page.ARENA) {
            String status = "Фильтр: " + filterName() + "  •  сектор: " + state.zoneIndex() + "  •  " + state.zoneStatus();
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(status).formatted(Formatting.GRAY),
                    width / 2, Math.min(height - 22, 218), 0xFFFFFF);
        } else if (!state.admin()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Настройки с серыми кнопками доступны администратору OZ").formatted(Formatting.DARK_GRAY),
                    width / 2, Math.min(height - 22, 218), 0xFFFFFF);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private record Toggle(String name, boolean enabled, int trigger) {}
}

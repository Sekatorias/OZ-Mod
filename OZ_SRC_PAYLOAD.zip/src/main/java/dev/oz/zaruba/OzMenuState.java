package dev.oz.zaruba;

import net.minecraft.network.PacketByteBuf;

public record OzMenuState(
        boolean admin,
        String zoneStatus,
        int teams,
        int borderSize,
        int shrinkStart,
        int shrinkSize,
        int shrinkDuration,
        int minuteMarker,
        int eternalStart,
        int glowStart,
        int glowEnd,
        int centerStart,
        int centerEnd,
        int pressure,
        int kit,
        int mode,
        int zoneFilter,
        int zoneIndex,
        boolean shrink,
        boolean eternal,
        boolean glow,
        boolean markers,
        boolean potions,
        boolean stew,
        boolean passiveAi,
        boolean phantoms,
        boolean joining,
        boolean nightVision,
        boolean diamondArmor,
        boolean friendlyFire,
        boolean advancements,
        boolean conduit,
        boolean center
) {
    public void write(PacketByteBuf buf) {
        buf.writeBoolean(admin);
        buf.writeString(zoneStatus == null ? "idle" : zoneStatus);
        buf.writeInt(teams);
        buf.writeInt(borderSize);
        buf.writeInt(shrinkStart);
        buf.writeInt(shrinkSize);
        buf.writeInt(shrinkDuration);
        buf.writeInt(minuteMarker);
        buf.writeInt(eternalStart);
        buf.writeInt(glowStart);
        buf.writeInt(glowEnd);
        buf.writeInt(centerStart);
        buf.writeInt(centerEnd);
        buf.writeInt(pressure);
        buf.writeInt(kit);
        buf.writeInt(mode);
        buf.writeInt(zoneFilter);
        buf.writeInt(zoneIndex);
        buf.writeBoolean(shrink);
        buf.writeBoolean(eternal);
        buf.writeBoolean(glow);
        buf.writeBoolean(markers);
        buf.writeBoolean(potions);
        buf.writeBoolean(stew);
        buf.writeBoolean(passiveAi);
        buf.writeBoolean(phantoms);
        buf.writeBoolean(joining);
        buf.writeBoolean(nightVision);
        buf.writeBoolean(diamondArmor);
        buf.writeBoolean(friendlyFire);
        buf.writeBoolean(advancements);
        buf.writeBoolean(conduit);
        buf.writeBoolean(center);
    }

    public static OzMenuState read(PacketByteBuf buf) {
        return new OzMenuState(
                buf.readBoolean(),
                buf.readString(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean(),
                buf.readBoolean()
        );
    }
}

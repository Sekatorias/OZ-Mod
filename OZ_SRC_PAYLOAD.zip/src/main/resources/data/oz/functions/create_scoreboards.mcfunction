#
# Create all scoreboards
#
# Tag: #minecraft:load
#

# Common scoreboards
scoreboard objectives add ozTick dummy
scoreboard objectives add ozState dummy
scoreboard objectives add ozMM dummy
scoreboard objectives add ozNextMM dummy
scoreboard objectives add ozBSize dummy
scoreboard objectives add ozSBStart dummy
scoreboard objectives add ozSBDur dummy
scoreboard objectives add ozSBSize dummy
scoreboard objectives add ozEternal dummy
scoreboard objectives add ozGlow dummy
scoreboard objectives add ozGlowEnd dummy
scoreboard objectives add ozCenterStart dummy
scoreboard objectives add ozCenterEnd dummy
scoreboard objectives add ozFxTick dummy
scoreboard objectives add ozCoord dummy
scoreboard objectives add ozEnabled dummy
scoreboard objectives add ozPotion dummy
scoreboard objectives add ozDiaChest dummy
scoreboard objectives add ozLobby dummy "OZ | Лобби"
scoreboard objectives add ozKit dummy

# Lobby scoreboards
scoreboard objectives add ozOpt trigger
scoreboard objectives add ozTeams dummy

# Pre-generation scoreboards
scoreboard objectives add ozPG dummy "Предзагрузка"
scoreboard objectives add ozPGQueue dummy "Очередь выгрузки"

# OZ scoreboards
scoreboard objectives add ozMin dummy
scoreboard objectives add ozHealth health "Здоровье"
scoreboard objectives setdisplay list ozHealth
scoreboard objectives add ozDeaths deathCount "Смерти"
scoreboard objectives add ozAliveTime minecraft.custom:minecraft.time_since_death "Время жизни"
scoreboard objectives add ozDmgDealt minecraft.custom:minecraft.damage_dealt "Нанесённый урон"
scoreboard objectives add ozDmgTaken minecraft.custom:minecraft.damage_taken "Полученный урон"
scoreboard objectives add ozKills minecraft.custom:minecraft.player_kills "Убийства"

# Автоматический выбор новых арен
scoreboard objectives add ozZone dummy

# OZ v10: dynamic match pressure
scoreboard objectives add ozPressure dummy
scoreboard objectives add ozMatchTick dummy
scoreboard objectives add ozTimer dummy

# Integer constants for v10 calculations
scoreboard players set #2 ozPressure 2
scoreboard players set #4 ozPressure 4
scoreboard players set #5 ozPressure 5
scoreboard players set #20 ozPressure 20
scoreboard players set #50 ozPressure 50
scoreboard players set #100 ozPressure 100
scoreboard players set #1200 ozPressure 1200
scoreboard players set #250 ozPressure 250
scoreboard players set #999 ozZone 999

# OZ v10.3 timer constants
scoreboard players set #20 ozTimer 20
scoreboard players set #60 ozTimer 60
scoreboard players set #100 ozTimer 100
scoreboard players set #1000 ozTimer 1000

# Сброс настроек нового лобби.
# При автоматическом переносе зоны настройки сохраняются.
execute unless score ZAutoSetup ozZone matches 1 run function oz:lobby/reset_options_body

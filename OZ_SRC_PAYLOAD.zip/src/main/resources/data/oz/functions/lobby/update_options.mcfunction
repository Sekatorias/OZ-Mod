#
# Update the option triggered by the player
#
# Entity: the player updating the option
#


########
# Page 1
########

# >>>>>>> Join a team manually
# 1     - Solo
# 2     - Spectate
# 3..16 - Teams
execute if score @s ozOpt matches 1 run team leave @s
execute if score @s ozOpt matches 2 run team join spectate
execute if score @s ozOpt matches 3 if score OZJoining ozEnabled matches 1 run team join redstone
execute if score @s ozOpt matches 4 if score OZJoining ozEnabled matches 1 run team join gold
execute if score @s ozOpt matches 5 if score OZJoining ozEnabled matches 1 run team join slime
execute if score @s ozOpt matches 6 if score OZJoining ozEnabled matches 1 run team join diamond
execute if score @s ozOpt matches 7 if score OZJoining ozEnabled matches 1 run team join water
execute if score @s ozOpt matches 8 if score OZJoining ozEnabled matches 1 run team join purpur
execute if score @s ozOpt matches 9 if score OZJoining ozEnabled matches 1 run team join stone
execute if score @s ozOpt matches 10 if score OZJoining ozEnabled matches 1 run team join netherwart
execute if score @s ozOpt matches 11 if score OZJoining ozEnabled matches 1 run team join acacia
execute if score @s ozOpt matches 12 if score OZJoining ozEnabled matches 1 run team join grass
execute if score @s ozOpt matches 13 if score OZJoining ozEnabled matches 1 run team join prismarine
execute if score @s ozOpt matches 14 if score OZJoining ozEnabled matches 1 run team join lapis
execute if score @s ozOpt matches 15 if score OZJoining ozEnabled matches 1 run team join chorus
execute if score @s ozOpt matches 16 if score OZJoining ozEnabled matches 1 run team join bedrock

# >>>> Adjust number of teams (min=2, max=14)
# 17 - Reduce number of teams (or cycle to max)
# 18 - Increase number of teams (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 17 run scoreboard players remove OZ ozTeams 1
execute if score @s[tag=admin] ozOpt matches 18 run scoreboard players add OZ ozTeams 1
execute if score OZ ozTeams matches 15.. run scoreboard players set OZ ozTeams 2
execute if score OZ ozTeams matches ..1 run scoreboard players set OZ ozTeams 14

# 19 - Randomize teams
execute if score @s[tag=admin] ozOpt matches 19 run team leave @a[team=!spectate]
execute if score @s[tag=admin] ozOpt matches 19 run function oz:lobby/randomize_teams
execute if score @s[tag=admin] ozOpt matches 19 run scoreboard players set OZJoining ozEnabled 0
execute if score @s[tag=admin] ozOpt matches 19 run data modify storage oz:text Icon.Joining set from storage oz:text Icon.Disabled

# >>>> Adjust world size (min=496, max=3056)
# 20 - Reduce world size by 512 (or cycle to max)
# 21 - Increase world size by 512 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 20 run scoreboard players remove OZ ozBSize 512
execute if score @s[tag=admin] ozOpt matches 21 run scoreboard players add OZ ozBSize 512
execute if score OZ ozBSize matches 3057.. run scoreboard players set OZ ozBSize 496
execute if score OZ ozBSize matches ..495 run scoreboard players set OZ ozBSize 3056

# >>>> Adjust border shrink start (min=0, max=100)
# 22 - Reduce border shrink start by 10 (or cycle to max)
# 23 - Increase border shrink start by 10 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 22 run scoreboard players remove OZ ozSBStart 10
execute if score @s[tag=admin] ozOpt matches 23 run scoreboard players add OZ ozSBStart 10
execute if score OZ ozSBStart matches 101.. run scoreboard players set OZ ozSBStart 0
execute if score OZ ozSBStart matches ..-1 run scoreboard players set OZ ozSBStart 100

# >>>> Adjust border shrink size (min=16, max=496)
# 24 - Reduce border shrink size by 96 (or cycle to max)
# 25 - Increase border shrink size by 96 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 24 run scoreboard players remove OZ ozSBSize 96
execute if score @s[tag=admin] ozOpt matches 25 run scoreboard players add OZ ozSBSize 96
execute if score OZ ozSBSize matches 497.. run scoreboard players set OZ ozSBSize 16
execute if score OZ ozSBSize matches ..15 run scoreboard players set OZ ozSBSize 496

# >>>> Adjust border shrink duration (min=10, max=100)
# 26 - Reduce border shrink duration by 10 (or cycle to max)
# 27 - Increase border shrink duration by 10 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 26 run scoreboard players remove OZ ozSBDur 10
execute if score @s[tag=admin] ozOpt matches 27 run scoreboard players add OZ ozSBDur 10
execute if score OZ ozSBDur matches 101.. run scoreboard players set OZ ozSBDur 10
execute if score OZ ozSBDur matches ..9 run scoreboard players set OZ ozSBDur 100

# 28 - Pre-generate
execute if score @s[tag=admin] ozOpt matches 28 run function oz:pre_generation/start

# 29 - Toggle Shrinking
execute if score @s[tag=admin] ozOpt matches 29 run execute store success score OZShrink ozEnabled run execute if score OZShrink ozEnabled matches 0
execute if score OZShrink ozEnabled matches 1 run data modify storage oz:text Icon.Shrink set from storage oz:text Icon.Enabled
execute if score OZShrink ozEnabled matches 0 run data modify storage oz:text Icon.Shrink set from storage oz:text Icon.Disabled

# 30 - Start
execute if score @s[tag=admin] ozOpt matches 30 run function oz:start

# 31..33 - Match mode
execute if score @s[tag=admin] ozOpt matches 31 run function oz:mode/apply_standard
execute if score @s[tag=admin] ozOpt matches 32 run function oz:mode/apply_elimination
execute if score @s[tag=admin] ozOpt matches 33 run function oz:mode/apply_no_regen

########
# Page 2
########

# >>>> Adjust minute marker (min=10, max=60)
# 100 - Reduce minute marker by 10 (or cycle to max)
# 101 - Increase minute marker by 10 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 100 run scoreboard players remove OZ ozMM 10
execute if score @s[tag=admin] ozOpt matches 101 run scoreboard players add OZ ozMM 10
execute if score OZ ozMM matches 61.. run scoreboard players set OZ ozMM 10
execute if score OZ ozMM matches ..9 run scoreboard players set OZ ozMM 60

# >>>> Adjust Eternal day start (min=0, max=100)
# 102 - Reduce eternal day start by 10 (or cycle to max)
# 103 - Increase eternal day start by 10 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 102 run scoreboard players remove OZ ozEternal 10
execute if score @s[tag=admin] ozOpt matches 103 run scoreboard players add OZ ozEternal 10
execute if score OZ ozEternal matches 101.. run scoreboard players set OZ ozEternal 0
execute if score OZ ozEternal matches ..-1 run scoreboard players set OZ ozEternal 100

# >>>> Adjust Glowing start (min=0, max=190)
# 104 - Reduce glowing start by 10 (or cycle to max)
# 105 - Increase glowing start by 10 (or cycle to min)
execute if score @s[tag=admin] ozOpt matches 104 run scoreboard players remove OZ ozGlow 10
execute if score @s[tag=admin] ozOpt matches 105 run scoreboard players add OZ ozGlow 10
execute if score OZ ozGlow matches 191.. run scoreboard players set OZ ozGlow 0
execute if score OZ ozGlow matches ..-1 run scoreboard players set OZ ozGlow 190

# 106 - Toggle Eternal day
execute if score @s[tag=admin] ozOpt matches 106 run execute store success score OZEternal ozEnabled run execute if score OZEternal ozEnabled matches 0
execute if score OZEternal ozEnabled matches 1 run data modify storage oz:text Icon.Eternal set from storage oz:text Icon.Enabled
execute if score OZEternal ozEnabled matches 0 run data modify storage oz:text Icon.Eternal set from storage oz:text Icon.Disabled

# 107 - Toggle Glowing
execute if score @s[tag=admin] ozOpt matches 107 run execute store success score OZGlow ozEnabled run execute if score OZGlow ozEnabled matches 0
execute if score OZGlow ozEnabled matches 1 run data modify storage oz:text Icon.Glow set from storage oz:text Icon.Enabled
execute if score OZGlow ozEnabled matches 0 run data modify storage oz:text Icon.Glow set from storage oz:text Icon.Disabled

# 108 - Toggle Markers
execute if score @s[tag=admin] ozOpt matches 108 run execute store success score OZMarkers ozEnabled run execute if score OZMarkers ozEnabled matches 0
execute if score OZMarkers ozEnabled matches 1 run data modify storage oz:text Icon.Marker set from storage oz:text Icon.Enabled
execute if score OZMarkers ozEnabled matches 0 run data modify storage oz:text Icon.Marker set from storage oz:text Icon.Disabled

# 109 - Toggle Strong Potions
execute if score @s[tag=admin] ozOpt matches 109 run execute store success score OZPotions ozEnabled run execute if score OZPotions ozEnabled matches 0
execute if score OZPotions ozEnabled matches 1 run data modify storage oz:text Icon.Potion set from storage oz:text Icon.Enabled
execute if score OZPotions ozEnabled matches 0 run data modify storage oz:text Icon.Potion set from storage oz:text Icon.Disabled

# 110 - Toggle Suspicious Stew
execute if score @s[tag=admin] ozOpt matches 110 run execute store success score OZStew ozEnabled run execute if score OZStew ozEnabled matches 0
execute if score OZStew ozEnabled matches 1 run data modify storage oz:text Icon.Stew set from storage oz:text Icon.Enabled
execute if score OZStew ozEnabled matches 0 run data modify storage oz:text Icon.Stew set from storage oz:text Icon.Disabled

# 111 - Toggle Passive Mobs
execute if score @s[tag=admin] ozOpt matches 111 run execute store success score OZPassiveAI ozEnabled run execute if score OZPassiveAI ozEnabled matches 0
execute if score OZPassiveAI ozEnabled matches 1 run data modify storage oz:text Icon.Passive set from storage oz:text Icon.Enabled
execute if score OZPassiveAI ozEnabled matches 0 run data modify storage oz:text Icon.Passive set from storage oz:text Icon.Disabled

# 112 - Toggle Phantoms
execute if score @s[tag=admin] ozOpt matches 112 run execute store success score OZPhantoms ozEnabled run execute if score OZPhantoms ozEnabled matches 0
execute if score OZPhantoms ozEnabled matches 1 run data modify storage oz:text Icon.Phantom set from storage oz:text Icon.Enabled
execute if score OZPhantoms ozEnabled matches 0 run data modify storage oz:text Icon.Phantom set from storage oz:text Icon.Disabled

# 113 - Toggle Team joining
execute if score @s[tag=admin] ozOpt matches 113 run execute store success score OZJoining ozEnabled run execute if score OZJoining ozEnabled matches 0
execute if score OZJoining ozEnabled matches 1 run data modify storage oz:text Icon.Joining set from storage oz:text Icon.Enabled
execute if score OZJoining ozEnabled matches 0 run data modify storage oz:text Icon.Joining set from storage oz:text Icon.Disabled

# 114 - Toggle Night vision
execute if score @s[tag=admin] ozOpt matches 114 run execute store success score OZNightVision ozEnabled run execute if score OZNightVision ozEnabled matches 0
execute if score OZNightVision ozEnabled matches 1 run data modify storage oz:text Icon.NightVision set from storage oz:text Icon.Enabled
execute if score OZNightVision ozEnabled matches 0 run data modify storage oz:text Icon.NightVision set from storage oz:text Icon.Disabled

# 115 - Toggle Diamond chestplates
execute if score @s[tag=admin] ozOpt matches 115 run execute store success score OZDiamondArmor ozEnabled run execute if score OZDiamondArmor ozEnabled matches 0
execute if score OZDiamondArmor ozEnabled matches 1 run data modify storage oz:text Icon.DiamondChestplate set from storage oz:text Icon.Enabled
execute if score OZDiamondArmor ozEnabled matches 0 run data modify storage oz:text Icon.DiamondChestplate set from storage oz:text Icon.Disabled

# 116 - Toggle Friendly fire
execute if score @s[tag=admin] ozOpt matches 116 run execute store success score OZFriendlyFire ozEnabled run execute if score OZFriendlyFire ozEnabled matches 0
execute if score OZFriendlyFire ozEnabled matches 1 run data modify storage oz:text Icon.FriendlyFire set from storage oz:text Icon.Enabled
execute if score OZFriendlyFire ozEnabled matches 0 run data modify storage oz:text Icon.FriendlyFire set from storage oz:text Icon.Disabled

# 117 - Toggle Show Advancements
execute if score @s[tag=admin] ozOpt matches 117 run execute store success score OZAdvancements ozEnabled run execute if score OZAdvancements ozEnabled matches 0
execute if score OZAdvancements ozEnabled matches 1 run data modify storage oz:text Icon.ShowAdvancements set from storage oz:text Icon.Enabled
execute if score OZAdvancements ozEnabled matches 0 run data modify storage oz:text Icon.ShowAdvancements set from storage oz:text Icon.Disabled

# 118 - Toggle Conduit Power
execute if score @s[tag=admin] ozOpt matches 118 run execute store success score OZConduit ozEnabled run execute if score OZConduit ozEnabled matches 0
execute if score OZConduit ozEnabled matches 1 run data modify storage oz:text Icon.ConduitPower set from storage oz:text Icon.Enabled
execute if score OZConduit ozEnabled matches 0 run data modify storage oz:text Icon.ConduitPower set from storage oz:text Icon.Disabled

# 119 - Toggle center beacon
execute if score @s[tag=admin] ozOpt matches 119 run execute store success score OZCenter ozEnabled run execute if score OZCenter ozEnabled matches 0
execute if score OZCenter ozEnabled matches 1 run data modify storage oz:text Icon.Center set from storage oz:text Icon.Enabled
execute if score OZCenter ozEnabled matches 0 run data modify storage oz:text Icon.Center set from storage oz:text Icon.Disabled

# 120/121 - Center beacon start (0..190)
execute if score @s[tag=admin] ozOpt matches 120 run scoreboard players remove OZ ozCenterStart 10
execute if score @s[tag=admin] ozOpt matches 121 run scoreboard players add OZ ozCenterStart 10
execute if score OZ ozCenterStart matches 191.. run scoreboard players set OZ ozCenterStart 0
execute if score OZ ozCenterStart matches ..-1 run scoreboard players set OZ ozCenterStart 190

# 122/123 - Center beacon end (10..200)
execute if score @s[tag=admin] ozOpt matches 122 run scoreboard players remove OZ ozCenterEnd 10
execute if score @s[tag=admin] ozOpt matches 123 run scoreboard players add OZ ozCenterEnd 10
execute if score OZ ozCenterEnd matches 201.. run scoreboard players set OZ ozCenterEnd 10
execute if score OZ ozCenterEnd matches ..9 run scoreboard players set OZ ozCenterEnd 200

# 124/125 - Sync center timing with border shrinking
execute if score @s[tag=admin] ozOpt matches 124 run scoreboard players operation OZ ozCenterStart = OZ ozSBStart
execute if score @s[tag=admin] ozOpt matches 125 run scoreboard players operation OZ ozCenterEnd = OZ ozSBStart
execute if score @s[tag=admin] ozOpt matches 125 run scoreboard players operation OZ ozCenterEnd += OZ ozSBDur

# 126/127 - Player glow end (10..200)
execute if score @s[tag=admin] ozOpt matches 126 run scoreboard players remove OZ ozGlowEnd 10
execute if score @s[tag=admin] ozOpt matches 127 run scoreboard players add OZ ozGlowEnd 10
execute if score OZ ozGlowEnd matches 201.. run scoreboard players set OZ ozGlowEnd 10
execute if score OZ ozGlowEnd matches ..9 run scoreboard players set OZ ozGlowEnd 200

# 128/129 - Sync player glow timing with border shrinking
execute if score @s[tag=admin] ozOpt matches 128 run scoreboard players operation OZ ozGlow = OZ ozSBStart
execute if score @s[tag=admin] ozOpt matches 129 run scoreboard players operation OZ ozGlowEnd = OZ ozSBStart
execute if score @s[tag=admin] ozOpt matches 129 run scoreboard players operation OZ ozGlowEnd += OZ ozSBDur

# Keep end strictly after start, and clamp sync results
execute if score OZ ozCenterStart matches 191.. run scoreboard players set OZ ozCenterStart 190
execute if score OZ ozCenterEnd matches 201.. run scoreboard players set OZ ozCenterEnd 200
execute if score OZ ozCenterStart >= OZ ozCenterEnd run scoreboard players operation OZ ozCenterEnd = OZ ozCenterStart
execute if score OZ ozCenterStart >= OZ ozCenterEnd run scoreboard players add OZ ozCenterEnd 10
execute if score OZ ozCenterEnd matches 201.. run scoreboard players set OZ ozCenterEnd 200
execute if score OZ ozCenterEnd matches 200 if score OZ ozCenterStart matches 200.. run scoreboard players set OZ ozCenterStart 190

execute if score OZ ozGlow matches 191.. run scoreboard players set OZ ozGlow 190
execute if score OZ ozGlowEnd matches 201.. run scoreboard players set OZ ozGlowEnd 200
execute if score OZ ozGlow >= OZ ozGlowEnd run scoreboard players operation OZ ozGlowEnd = OZ ozGlow
execute if score OZ ozGlow >= OZ ozGlowEnd run scoreboard players add OZ ozGlowEnd 10
execute if score OZ ozGlowEnd matches 201.. run scoreboard players set OZ ozGlowEnd 200
execute if score OZ ozGlowEnd matches 200 if score OZ ozGlow matches 200.. run scoreboard players set OZ ozGlow 190


# 205..207 - Death Pressure strength
execute if score @s[tag=admin] ozOpt matches 205 run scoreboard players set OZ ozPressure 0
execute if score @s[tag=admin] ozOpt matches 206 run scoreboard players set OZ ozPressure 50
execute if score @s[tag=admin] ozOpt matches 207 run scoreboard players set OZ ozPressure 100

# 208..210 - Стартовый набор
execute if score @s[tag=admin] ozOpt matches 208 run scoreboard players set OZ ozKit 0
execute if score @s[tag=admin] ozOpt matches 209 run scoreboard players set OZ ozKit 1
execute if score @s[tag=admin] ozOpt matches 210 run scoreboard players set OZ ozKit 2
execute if score @s[tag=admin] ozOpt matches 208..210 run function oz:lobby/update_kit_name

# 200..204 - Автоматический выбор зоны
execute if score @s[tag=admin] ozOpt matches 200 run function oz:zone/filter/any
execute if score @s[tag=admin] ozOpt matches 201 run function oz:zone/filter/water
execute if score @s[tag=admin] ozOpt matches 202 run function oz:zone/filter/mountain
execute if score @s[tag=admin] ozOpt matches 203 run function oz:zone/filter/mixed
execute if score @s[tag=admin] ozOpt matches 204 run function oz:zone/new

execute if score @s[tag=admin] ozOpt matches 19 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Команды перемешаны","color":"aqua"}]
execute if score @s[tag=!admin] ozOpt matches 17.. run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Эта настройка доступна только администратору OZ","color":"red"}]
execute if score @s ozOpt matches 3..16 if score OZJoining ozEnabled matches 0 run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Команды уже заблокированы","color":"red"}]
# Handle sound effects and permission errors
execute if score @s ozOpt matches ..2 at @s run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 1 1
execute if score @s ozOpt matches 3..16 at @s run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 1 1
execute if entity @s[tag=admin] if score @s ozOpt matches 17.. unless score @s ozOpt matches 30 at @s run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 1 1

# Native GUI refreshes itself; no settings book rebuild is needed.

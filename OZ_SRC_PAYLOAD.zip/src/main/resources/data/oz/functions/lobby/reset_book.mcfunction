# OZ native GUI replaced the settings book.
# Remove only the old OZ book if a player still has one from an earlier build.
clear @s minecraft:written_book{title:"OZ",author:"OZ"} 1

# Обновить число участников в лобби
execute store result score Участники ozLobby run execute if entity @a[team=!spectate]

#
# Reset all the options
#
# Tag: #oz:events/on_lobby
#

scoreboard players set OZ ozTeams 4
scoreboard players set OZ ozMM 20
scoreboard players set OZ ozNextMM 0
scoreboard players set OZ ozBSize 1008
scoreboard players set OZ ozSBStart 18
scoreboard players set OZ ozSBSize 112
scoreboard players set OZ ozSBDur 24
scoreboard players set OZ ozEternal 70
scoreboard players set OZ ozGlow 30
scoreboard players set OZ ozGlowEnd 42
scoreboard players set OZ ozCenterStart 18
scoreboard players set OZ ozCenterEnd 42
scoreboard players set OZ ozPressure 100
scoreboard players set OZ ozKit 0
scoreboard players set OZShrink ozEnabled 1
scoreboard players set OZMarkers ozEnabled 0
scoreboard players set OZDiamondArmor ozEnabled 1
scoreboard players set OZEternal ozEnabled 0
scoreboard players set OZGlow ozEnabled 1
scoreboard players set OZCenter ozEnabled 1
scoreboard players set OZPotions ozEnabled 1
scoreboard players set OZStew ozEnabled 1
scoreboard players set OZPassiveAI ozEnabled 1
scoreboard players set OZPhantoms ozEnabled 1
scoreboard players set OZJoining ozEnabled 1
scoreboard players set OZNightVision ozEnabled 0
scoreboard players set OZFriendlyFire ozEnabled 1
scoreboard players set OZAdvancements ozEnabled 1
scoreboard players set OZConduit ozEnabled 0

# OZ match mode (default)
function oz:mode/apply_standard

# Display options for toggles

data modify storage oz:text Icon.Shrink set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Marker set from storage oz:text Icon.Disabled
data modify storage oz:text Icon.DiamondChestplate set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Eternal set from storage oz:text Icon.Disabled
data modify storage oz:text Icon.Glow set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Center set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Potion set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Stew set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Passive set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Phantom set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.Joining set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.NightVision set from storage oz:text Icon.Disabled
data modify storage oz:text Icon.FriendlyFire set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.ShowAdvancements set from storage oz:text Icon.Enabled
data modify storage oz:text Icon.ConduitPower set from storage oz:text Icon.Disabled

# Java mod bridge: config/oz/oz.json overrides OZ match defaults.
oz config apply

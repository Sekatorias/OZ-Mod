data modify storage oz:text Kit.Name set value "{\"text\":\"Без кита\",\"color\":\"gray\",\"bold\":true}"
execute if score OZ ozKit matches 1 run data modify storage oz:text Kit.Name set value "{\"text\":\"Деревянный\",\"color\":\"gold\",\"bold\":true}"
execute if score OZ ozKit matches 2 run data modify storage oz:text Kit.Name set value "{\"text\":\"Каменный\",\"color\":\"dark_gray\",\"bold\":true}"

# Завершить матч и перевести игроков в наблюдатели
scoreboard players set OZ ozState 5
bossbar set oz:timer visible false
effect clear @a[tag=oz_glow_managed] minecraft:glowing
tag @a remove oz_glow_managed
execute as @a run function oz:running/make_player_spectator
function #oz:events/on_complete

title @a title {"text":"МАТЧ ЗАВЕРШЁН","color":"gold","bold":true}
title @a subtitle {"text":"Итоги доступны администратору","color":"gray"}
tellraw @a[tag=admin] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"[ПОКАЗАТЬ НАГРАДЫ]","color":"gold","bold":true,"clickEvent":{"action":"run_command","value":"/function oz:awards/reveal"},"hoverEvent":{"action":"show_text","value":"Показать итоги матча"}}]
tellraw @a[tag=admin] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Новый раунд: ","color":"gray"},{"text":"[СОЗДАТЬ ЛОББИ ЗДЕСЬ]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/function oz:setup"},"hoverEvent":{"action":"show_text","value":"Удалить остатки раунда и создать лобби в текущей точке"}},{"text":"  ","color":"gray"},{"text":"[ТОЛЬКО СБРОС]","color":"yellow","clickEvent":{"action":"run_command","value":"/function oz:reset"}}]

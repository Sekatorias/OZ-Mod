function oz:migration/legacy_entities

#
# Call the corresponding tick function for the current OZ state 
#
# Tag: #minecraft:tick
#

# ozState - The state machine scoreboard
#
# 1 - Lobby
# 3 - Start sequence
# 4 - OZ
# 5 - Awards
execute if score OZ ozState matches 1 run function oz:lobby/tick
execute if score OZ ozState matches 3 run function oz:starting/tick
execute if score OZ ozState matches 4 run function oz:running/tick

scoreboard players add OZ ozTick 1

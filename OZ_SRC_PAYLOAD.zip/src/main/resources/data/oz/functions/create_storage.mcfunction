#
# Create all NBT constants
#
# Tag: #minecraft:load
#

# Initialize the JSON text parts
data modify storage oz:text Icon.Enabled set value "{\"text\":\"[+]\",\"color\":\"dark_green\"}"
data modify storage oz:text Icon.Disabled set value "{\"text\":\"[-]\",\"color\":\"red\"}"
data modify storage oz:text Mode.Name set value "{\"text\":\"Стандарт OZ\",\"color\":\"green\",\"bold\":true}"
data modify storage oz:text Mode.Start set value "{\"text\":\"Респавны до финала\",\"color\":\"gray\"}"

data modify storage oz:dynamic_tp Pos set value [0d, 0d, 0d]

# Название фильтра автоматической зоны
data modify storage oz:text Zone.Name set value "{\"text\":\"Любая\",\"color\":\"green\",\"bold\":true}"
data modify storage oz:text Kit.Name set value "{\"text\":\"Без кита\",\"color\":\"gray\",\"bold\":true}"

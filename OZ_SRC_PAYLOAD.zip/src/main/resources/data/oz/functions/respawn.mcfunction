#
# Utility to allow a player to be respawned in
#
# Entity: The player to respawn into the game
#

# Reset spectator state
tag @s remove spectator
effect clear @s

# Reset playing state
tag @s add playing
scoreboard players reset @s ozDeaths

# Now we can finally put the player into survival mode
gamemode survival @s
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" возвращён в матч администратором","color":"gray"}]

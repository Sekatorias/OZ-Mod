# Внутренний полный сброс раунда.
# Сохраняет Origins/mod persistent data и историю автоматических OZ-зон.

scoreboard players set OZ ozState 0
scoreboard players set OZ ozTick 0
scoreboard players set OZ ozMin 0
schedule clear oz:pre_generation/tick
bossbar set oz:pregen visible false
bossbar set oz:timer visible false

# Остановить незавершённый поиск новой зоны, но НЕ сбрасывать его историю.
function oz:zone/search/cancel_internal

# Legacy cleanup for worlds upgraded from older OZ versions
function oz:migration/legacy_entities

# Remove pre-generation markers and their force-loaded chunks
execute as @e[type=minecraft:marker,tag=pre_generator,tag=forceloaded] at @s run forceload remove ~ ~
kill @e[type=minecraft:marker,tag=pre_generator]

# Remove the persistent arena-center marker and release its one force-loaded chunk
execute as @e[type=minecraft:marker,tag=oz_arena_center] at @s run forceload remove ~ ~
kill @e[type=minecraft:marker,tag=oz_arena_center]
scoreboard players reset CenterX ozCoord
scoreboard players reset CenterZ ozCoord
scoreboard players set OZ ozFxTick 0
effect clear @a[tag=oz_glow_managed] minecraft:glowing
tag @a remove oz_glow_managed

# Remove a previous lobby wherever it was created
execute at @e[type=minecraft:armor_stand,tag=lobbycenter] run fill ~-12 250 ~-12 ~11 289 ~11 minecraft:air
kill @e[tag=lobby]

# Полный игровой сброс игроков. Origins и сторонние mod scoreboard не затрагиваются.
function oz:players/reset_all

# Reset round/team state
tag @a remove playing
tag @a remove spectator
tag @a remove pre_generator
tag @a remove admin
team leave @a
execute as @a at @s run spawnpoint @s ~ ~ ~

# Restore ordinary world behavior between matches
execute in minecraft:overworld run gamerule naturalRegeneration true
execute in minecraft:the_nether run gamerule naturalRegeneration true
execute in minecraft:the_end run gamerule naturalRegeneration true
execute in minecraft:overworld run gamerule randomTickSpeed 3
execute in minecraft:the_nether run gamerule randomTickSpeed 3
execute in minecraft:the_end run gamerule randomTickSpeed 3
gamerule doFireTick true
gamerule doDaylightCycle true
gamerule doInsomnia true
gamerule announceAdvancements true
gamerule spectatorsGenerateChunks true


# Clear v10 runtime pressure state (configuration OZ/ozPressure is kept until lobby defaults are reapplied).
scoreboard players reset @a ozPressure
scoreboard players reset OZPlayers ozPressure
scoreboard players reset OZEvents ozPressure
scoreboard players reset OZSpeedPct ozPressure
scoreboard players reset OZSpeedTier ozPressure
scoreboard players reset OZFinalAt ozPressure
scoreboard players reset OZBaseFinalAt ozPressure
scoreboard players reset OZCutTicks ozPressure
scoreboard players reset OZCutSec ozPressure
scoreboard players reset OZShrinkTick ozPressure
scoreboard players set OZFinalActive ozEnabled 0
scoreboard players set OZBorderDone ozEnabled 0
scoreboard players set OZ ozMatchTick 0
recipe take @a oz:time_back
recipe take @a oz:time_forward

# Release the arena border; setup will center it again at the new lobby
execute in minecraft:overworld run worldborder center 0 0
execute in minecraft:overworld run worldborder set 59999968
execute in minecraft:the_nether run worldborder center 0 0
execute in minecraft:the_nether run worldborder set 59999968
execute in minecraft:the_end run worldborder center 0 0
execute in minecraft:the_end run worldborder set 59999968
scoreboard objectives setdisplay sidebar

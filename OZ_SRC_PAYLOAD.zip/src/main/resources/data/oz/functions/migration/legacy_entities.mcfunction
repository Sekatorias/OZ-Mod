# OZ mod migration: delete old datapack arena-search entities and release their tickets.
# Java now persists the grid origin and samples BiomeSource without loading candidate chunks.
execute as @e[type=minecraft:marker,tag=oz_zone_origin] at @s run forceload remove ~ ~
execute as @e[type=minecraft:marker,tag=oz_zone_candidate] at @s run forceload remove ~ ~
execute as @e[type=minecraft:armor_stand,tag=oz_zone_origin] at @s run forceload remove ~ ~
execute as @e[type=minecraft:armor_stand,tag=oz_zone_candidate] at @s run forceload remove ~ ~
kill @e[type=minecraft:marker,tag=oz_zone_origin]
kill @e[type=minecraft:marker,tag=oz_zone_candidate]
kill @e[type=minecraft:armor_stand,tag=oz_zone_origin]
kill @e[type=minecraft:armor_stand,tag=oz_zone_candidate]

# Old pre-generation stands can still exist in upgraded worlds.
execute as @e[type=minecraft:armor_stand,tag=pre_generator,tag=forceloaded] at @s run forceload remove ~ ~
kill @e[type=minecraft:armor_stand,tag=pre_generator]

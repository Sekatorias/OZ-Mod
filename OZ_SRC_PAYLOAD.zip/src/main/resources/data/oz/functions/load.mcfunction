function oz:migration/legacy_entities

# v10.8 migration: stop any scheduled callbacks left by Terrain Search 2.0.
schedule clear oz:zone/sample/batch_check
schedule clear oz:zone/sample/batch_process
schedule clear oz:zone/sample/single_process
schedule clear oz:zone/sample/batch_timeout
schedule clear oz:zone/sample/check

# Base OZ mode data. Do not re-enable respawns during an active final.
execute unless score OZMode ozEnabled matches 1..3 run scoreboard players set OZMode ozEnabled 1
execute unless score OZRespawns ozEnabled matches 0..1 run scoreboard players set OZRespawns ozEnabled 1
execute unless score OZNaturalRegen ozEnabled matches 0..1 run scoreboard players set OZNaturalRegen ozEnabled 1
execute if score OZMode ozEnabled matches 1 run function oz:mode/display_standard
execute if score OZMode ozEnabled matches 2 run function oz:mode/display_elimination
execute if score OZMode ozEnabled matches 3 run function oz:mode/display_no_regen

# Финальные ориентиры / свечение (совместимость с мирами до v8)
execute unless score OZ ozGlowEnd matches 10..200 run scoreboard players set OZ ozGlowEnd 100
execute unless score OZ ozCenterStart matches 0..190 run scoreboard players set OZ ozCenterStart 50
execute unless score OZ ozCenterEnd matches 10..200 run scoreboard players set OZ ozCenterEnd 100
execute unless score OZCenter ozEnabled matches 0..1 run scoreboard players set OZCenter ozEnabled 1
execute if score OZCenter ozEnabled matches 1 run data modify storage oz:text Icon.Center set from storage oz:text Icon.Enabled
execute if score OZCenter ozEnabled matches 0 run data modify storage oz:text Icon.Center set from storage oz:text Icon.Disabled
execute if score OZGlow ozEnabled matches 1 run data modify storage oz:text Icon.Glow set from storage oz:text Icon.Enabled
execute if score OZGlow ozEnabled matches 0 run data modify storage oz:text Icon.Glow set from storage oz:text Icon.Disabled

# Автоматические зоны. Zone Search 1.0 (стабильная логика v9.x).
# ZIndex сохраняется между reset и отмечает уже пройденные сектора.
execute unless score ZIndex ozZone matches 0.. run scoreboard players set ZIndex ozZone 0
execute unless score ZFilter ozZone matches 0..3 run scoreboard players set ZFilter ozZone 0
scoreboard players set ZState ozZone 0
execute if score ZFilter ozZone matches 0 run data modify storage oz:text Zone.Name set value "{\"text\":\"Любая\",\"color\":\"green\",\"bold\":true}"
execute if score ZFilter ozZone matches 1 run data modify storage oz:text Zone.Name set value "{\"text\":\"Вода >=30%\",\"color\":\"aqua\",\"bold\":true}"
execute if score ZFilter ozZone matches 2 run data modify storage oz:text Zone.Name set value "{\"text\":\"Горы >=30%\",\"color\":\"gold\",\"bold\":true}"
execute if score ZFilter ozZone matches 3 run data modify storage oz:text Zone.Name set value "{\"text\":\"Смешанная\",\"color\":\"light_purple\",\"bold\":true}"

# Базовое состояние нового мира
execute unless score OZ ozState matches 0..5 run scoreboard players set OZ ozState 0

# v10 compatibility defaults
execute unless score OZ ozPressure matches 0..100 run scoreboard players set OZ ozPressure 100

# Индикатор предзагрузки мира
bossbar add oz:pregen {"text":"OZ | Предзагрузка мира","color":"light_purple","bold":true}
bossbar set oz:pregen visible false
bossbar set oz:pregen color purple
bossbar set oz:pregen players @a
bossbar set oz:pregen style notched_10

# Постоянный таймер матча
bossbar add oz:timer {"text":"OZ | Таймер матча","color":"light_purple","bold":true}
bossbar set oz:timer visible false
bossbar set oz:timer color purple
bossbar set oz:timer style progress
bossbar set oz:timer max 1000
bossbar set oz:timer value 1000
bossbar set oz:timer players @a

function oz:players/reset_all
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Игровое состояние игроков очищено.","color":"gold"}]

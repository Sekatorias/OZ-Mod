function oz:mode/elimination

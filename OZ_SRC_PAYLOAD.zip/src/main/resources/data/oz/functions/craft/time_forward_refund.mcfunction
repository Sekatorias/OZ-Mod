give @s minecraft:copper_ingot 8
give @s minecraft:lapis_block 1
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Управление временем сейчас недоступно. Ресурсы возвращены.","color":"red"}]

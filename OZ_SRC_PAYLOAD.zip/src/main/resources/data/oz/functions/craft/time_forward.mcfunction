# OZ v10: 8 copper + lapis block -> move the sun 6 hours forwards.
clear @s minecraft:knowledge_book 1
advancement revoke @s only oz:crafting/time_forward
execute if score OZ ozState matches 4 if score OZEternal ozEnabled matches 0 run function oz:craft/time_forward_apply
execute unless score OZ ozState matches 4 run function oz:craft/time_forward_refund
execute if score OZ ozState matches 4 if score OZEternal ozEnabled matches 1 run function oz:craft/time_forward_refund

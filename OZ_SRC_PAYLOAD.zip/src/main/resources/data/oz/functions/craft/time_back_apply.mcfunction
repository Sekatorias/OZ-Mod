execute in minecraft:overworld run time add 18000
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 0.6
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" отмотал солнце на 6 часов назад","color":"gold"}]

# OZ v10: 8 copper + gold -> move the sun visually 6 hours backwards.
clear @s minecraft:knowledge_book 1
advancement revoke @s only oz:crafting/time_back
execute if score OZ ozState matches 4 if score OZEternal ozEnabled matches 0 run function oz:craft/time_back_apply
execute unless score OZ ozState matches 4 run function oz:craft/time_back_refund
execute if score OZ ozState matches 4 if score OZEternal ozEnabled matches 1 run function oz:craft/time_back_refund

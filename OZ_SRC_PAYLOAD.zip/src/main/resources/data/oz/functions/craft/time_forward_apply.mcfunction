execute in minecraft:overworld run time add 6000
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 1 1.4
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" передвинул солнце на 6 часов вперёд","color":"gold"}]

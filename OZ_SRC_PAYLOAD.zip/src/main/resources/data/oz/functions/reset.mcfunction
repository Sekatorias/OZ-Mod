# Полный сброс раунда без создания лобби
function oz:reset_internal
tag @s add admin
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Раунд сброшен","color":"gold"},{"text":" - Встаньте в центре новой арены и выполните ","color":"gray"},{"text":"/function oz:setup","color":"aqua"}]

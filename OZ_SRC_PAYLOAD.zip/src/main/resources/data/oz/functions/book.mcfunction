# Выдать исполнителю актуальную книгу настроек OZ.
# Книга помещается в первый слот панели быстрого доступа.
execute if entity @s[type=minecraft:player] run function oz:lobby/reset_book
execute if entity @s[type=minecraft:player] run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Книга настроек выдана","color":"gold"}]

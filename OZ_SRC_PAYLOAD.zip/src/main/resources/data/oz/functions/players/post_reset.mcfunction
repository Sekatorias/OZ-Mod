effect clear @a minecraft:saturation

# Полный сброс игрового состояния между раундами.
# Не трогает Origins/mod persistent data и сторонние scoreboard objectives.
clear @a
effect clear @a
experience set @a 0 levels
experience set @a 0 points
gamemode survival @a

# Восстановить здоровье и голод; saturation убирается на следующем тике.
effect give @a minecraft:instant_health 1 10 true
effect give @a minecraft:saturation 1 10 true
schedule function oz:players/post_reset 1t replace

# Очистить эндер-сундуки, чтобы ресурсы не переходили между раундами.
item replace entity @a enderchest.0 with minecraft:air
item replace entity @a enderchest.1 with minecraft:air
item replace entity @a enderchest.2 with minecraft:air
item replace entity @a enderchest.3 with minecraft:air
item replace entity @a enderchest.4 with minecraft:air
item replace entity @a enderchest.5 with minecraft:air
item replace entity @a enderchest.6 with minecraft:air
item replace entity @a enderchest.7 with minecraft:air
item replace entity @a enderchest.8 with minecraft:air
item replace entity @a enderchest.9 with minecraft:air
item replace entity @a enderchest.10 with minecraft:air
item replace entity @a enderchest.11 with minecraft:air
item replace entity @a enderchest.12 with minecraft:air
item replace entity @a enderchest.13 with minecraft:air
item replace entity @a enderchest.14 with minecraft:air
item replace entity @a enderchest.15 with minecraft:air
item replace entity @a enderchest.16 with minecraft:air
item replace entity @a enderchest.17 with minecraft:air
item replace entity @a enderchest.18 with minecraft:air
item replace entity @a enderchest.19 with minecraft:air
item replace entity @a enderchest.20 with minecraft:air
item replace entity @a enderchest.21 with minecraft:air
item replace entity @a enderchest.22 with minecraft:air
item replace entity @a enderchest.23 with minecraft:air
item replace entity @a enderchest.24 with minecraft:air
item replace entity @a enderchest.25 with minecraft:air
item replace entity @a enderchest.26 with minecraft:air

# Сбросить ванильные достижения и достижения OZ, не затрагивая модовые ветки.
advancement revoke @a from minecraft:story/root
advancement revoke @a from minecraft:nether/root
advancement revoke @a from minecraft:end/root
advancement revoke @a from minecraft:adventure/root
advancement revoke @a from minecraft:husbandry/root
advancement revoke @a from oz:root

# Сбросить OZ-статистику матча.
scoreboard players reset @a ozDeaths
scoreboard players reset @a ozAliveTime
scoreboard players reset @a ozDmgDealt
scoreboard players reset @a ozDmgTaken
scoreboard players reset @a ozKills
scoreboard players reset @a ozDiaChest
scoreboard players reset @a ozOpt

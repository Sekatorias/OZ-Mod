#
# Reveal the advancements
#

# Temporarily re-enable advancements if they have been switched off
execute if score OZAdvancements ozEnabled matches 0 run gamerule announceAdvancements true

advancement grant @a[team=!spectate] only oz:awards/winner revealed

advancement grant @a[team=!spectate] only oz:awards/early_exit revealed
advancement grant @a[team=!spectate] only oz:awards/first_blood revealed
advancement grant @a[team=!spectate] only oz:awards/mostly_harmless revealed
advancement grant @a[team=!spectate] only oz:awards/heavy_hitter revealed
advancement grant @a[team=!spectate] only oz:awards/tank revealed
advancement grant @a[team=!spectate] only oz:awards/mvp revealed

# Re-disable advancements
execute if score OZAdvancements ozEnabled matches 0 run gamerule announceAdvancements false

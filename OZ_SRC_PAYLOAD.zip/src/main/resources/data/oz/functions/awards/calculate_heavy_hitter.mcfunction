#
# Calculate and grant the heavy hitter advancement
#
# Tag: #oz:events/on_complete
#

scoreboard players set OZ ozPG 0
execute as @a[team=!spectate] run scoreboard players operation OZ ozPG > @s ozDmgDealt
execute as @a[team=!spectate] if score @s ozDmgDealt = OZ ozPG run advancement grant @s only oz:awards/heavy_hitter triggered
scoreboard players reset OZ ozPG

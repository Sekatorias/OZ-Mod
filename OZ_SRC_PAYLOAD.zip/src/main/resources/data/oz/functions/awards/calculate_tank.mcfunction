#
# Calculate and grant the tank advancement
#
# Tag: #oz:events/on_complete
#

scoreboard players set OZ ozPG 0
execute as @a[team=!spectate] run scoreboard players operation OZ ozPG > @s ozDmgTaken
execute as @a[team=!spectate] if score @s ozDmgTaken = OZ ozPG run advancement grant @s only oz:awards/tank triggered
scoreboard players reset OZ ozPG

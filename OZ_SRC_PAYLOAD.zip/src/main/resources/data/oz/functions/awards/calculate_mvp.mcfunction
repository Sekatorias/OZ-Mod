#
# Calculate and grant the MVP advancement
#
# Tag: #oz:events/on_complete
#

# Most kills is the first thing we check
scoreboard players set OZ ozPG 0
execute as @a[team=!spectate] run scoreboard players operation OZ ozPG > @s ozKills
execute as @a[team=!spectate] if score @s ozKills = OZ ozPG run advancement grant @s only oz:awards/mvp triggered_most_kills
execute unless entity @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true}}] run advancement grant @a[team=!spectate] only oz:awards/mvp triggered_most_kills

# Then we check most health based on those remaining.
#
# We need to guard these checks against 2 special case conditions:
#  - The player is alive and have taken no damage and don't have a scoreboard value
#  - The player has died and respawned and as a result has full health
#
# First we need to handle a missing scoreboard and immediately grant the advancement to any matching players
execute as @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true}}] unless score @s ozHealth matches 0.. run advancement grant @s only oz:awards/mvp triggered_most_health
# Next, we find the player with the max health but only if players who haven't taken damage exist,
# but only take into account players who have had no deaths
scoreboard players set OZ ozPG 0
execute unless entity @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] as @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true}}] unless score @s ozDeaths matches 1.. run scoreboard players operation OZ ozPG > @s ozHealth
execute unless entity @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] as @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true}}] if score @s ozHealth = OZ ozPG run advancement grant @s only oz:awards/mvp triggered_most_health
execute unless entity @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] run advancement grant @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true}}] only oz:awards/mvp triggered_most_health

# Finally, we check who dealt the most damage of those remaining
scoreboard players set OZ ozPG 0
execute as @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] run scoreboard players operation OZ ozPG > @s ozDmgDealt
execute as @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] if score @s ozDmgDealt = OZ ozPG run advancement grant @s only oz:awards/mvp triggered_most_damage_dealt
execute unless entity @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true,triggered_most_damage_dealt=true}}] run advancement grant @a[team=!spectate,advancements={oz:awards/mvp={triggered_most_kills=true,triggered_most_health=true}}] only oz:awards/mvp triggered_most_damage_dealt

scoreboard players reset OZ ozPG


#
# Check and grant the early exit advancement to the player if they are the first one
#
# Entity: The player who died
# Tag: #oz:events/on_player_death
#

execute unless entity @a[advancements={oz:awards/early_exit={triggered=true}}] run advancement grant @s only oz:awards/early_exit triggered

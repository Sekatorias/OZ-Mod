#
# Calculate and grant the mostly harmless advancement
#
# Tag: #oz:events/on_complete
#

scoreboard players set OZ ozPG 100000
execute as @a[team=!spectate] run scoreboard players operation OZ ozPG < @s ozDmgDealt
execute as @a[team=!spectate] if score @s ozDmgDealt = OZ ozPG run advancement grant @s only oz:awards/mostly_harmless triggered
scoreboard players reset OZ ozPG

#
# Ensure that the chunks are the current location are loaded
#
# Location: The location from which pre-generators will be generated
#

execute if score Dimension ozPG matches -1 in minecraft:the_nether store success score AlreadyLoadedOrigin ozPG run forceload query ~ ~
execute if score Dimension ozPG matches 0 in minecraft:overworld store success score AlreadyLoadedOrigin ozPG run forceload query ~ ~

execute if score Dimension ozPG matches -1 in minecraft:the_nether run forceload add ~ ~
execute if score Dimension ozPG matches 0 in minecraft:overworld run forceload add ~ ~

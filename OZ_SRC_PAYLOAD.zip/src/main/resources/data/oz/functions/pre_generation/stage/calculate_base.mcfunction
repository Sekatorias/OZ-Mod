#
# Calculate the base coordinates from which the cursor will be relative to
#

# Clone the lobby center's coordinates into the dynamic teleport scoreboard.
# This allows for scoreboard operations to be executed without losing track of these original coordinates.
execute store result score BaseX ozPG run data get entity @e[type=minecraft:armor_stand,tag=lobbycenter,limit=1] Pos[0]
execute store result score BaseZ ozPG run data get entity @e[type=minecraft:armor_stand,tag=lobbycenter,limit=1] Pos[2]

scoreboard players set Eight ozPG 8
scoreboard players set Two ozPG 2

# If the destination is located in the nether, divide the location by 8
execute if score Dimension ozPG matches -1 run scoreboard players operation BaseX ozPG /= Eight ozPG
execute if score Dimension ozPG matches -1 run scoreboard players operation BaseZ ozPG /= Eight ozPG


# As the lobby is centered in the border, divide the
# border size by two to calculate the distance from the edge
scoreboard players operation Radius ozPG = Diameter ozPG
scoreboard players operation Radius ozPG /= Two ozPG

# Update the coordinates to their final values
scoreboard players operation BaseX ozPG -= Radius ozPG
scoreboard players operation BaseZ ozPG -= Radius ozPG

# Clean up the temporary variables
scoreboard players reset Radius ozPG
scoreboard players reset Two ozPG
scoreboard players reset Eight ozPG

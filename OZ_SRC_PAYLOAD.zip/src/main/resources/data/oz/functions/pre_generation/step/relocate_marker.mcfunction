#
# Teleport the target marker to the desired location
#
# Entity: The marker
#

# Calculate the desired destination based off of the base coordinates + the relative ones
scoreboard players operation AbsoluteX ozPG = BaseX ozPG
scoreboard players operation AbsoluteZ ozPG = BaseZ ozPG
scoreboard players operation AbsoluteX ozPG += X ozPG
scoreboard players operation AbsoluteZ ozPG += Z ozPG

# Update storage with the new coordinates
execute store result storage oz:dynamic_tp Pos[0] double 1 run scoreboard players get AbsoluteX ozPG
execute store result storage oz:dynamic_tp Pos[1] double 1 run data get entity @s Pos[1]
execute store result storage oz:dynamic_tp Pos[2] double 1 run scoreboard players get AbsoluteZ ozPG

# Apply these coordinates to the target, effectively teleporting it
# There is no need to load the target chunk ahead of time, since @s selected entities stay in memory and do not have to be reselected
data modify entity @s Pos set from storage oz:dynamic_tp Pos

tag @s remove new
scoreboard players set @s ozPGQueue 1

execute at @s store success score AlreadyLoaded ozPG run forceload query ~ ~
# Load the new chunk, unless it is already loaded.
# Leave it alone in that case!
execute if score AlreadyLoaded ozPG matches 0 at @s run forceload add ~ ~
execute if score AlreadyLoaded ozPG matches 0 run tag @s add forceloaded
execute unless score AlreadyLoaded ozPG matches 0 run function oz:pre_generation/step/complete

#
# Complete the pre-generation
#

scoreboard objectives setdisplay sidebar ozLobby

scoreboard players reset * ozPG

tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Предзагрузка завершена","color":"green"}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

# Запустить предзагрузку арены
scoreboard players set Stage ozPG 0

tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Предзагрузка мира запущена","color":"aqua"},{"text":" - Это может занять некоторое время","color":"gray"}]

function oz:pre_generation/stage/next
schedule function oz:pre_generation/tick 1t

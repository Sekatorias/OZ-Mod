#
# Update the cursor's x coordinate for the pre-generation
#

execute if score Direction ozPG matches 1 run scoreboard players add X ozPG 16
execute unless score Direction ozPG matches 1 run scoreboard players remove X ozPG 16

#
# Reset the cursor variables for pre-generation
#

scoreboard players set X ozPG -1
scoreboard players set Z ozPG -1

#
# Update the cursor's z coordinate for the pre-generation
#

scoreboard players add Z ozPG 16

scoreboard players set Invert ozPG -1
scoreboard players operation Direction ozPG *= Invert ozPG
scoreboard players reset Invert ozPG

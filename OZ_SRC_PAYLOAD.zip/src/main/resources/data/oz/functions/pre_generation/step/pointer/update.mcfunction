#
# Upate the cursor variables for the pre-generation
#

function oz:pre_generation/step/pointer/update/x

execute if score X ozPG matches ..0 run function oz:pre_generation/step/pointer/update/z
execute if score X ozPG >= Diameter ozPG run function oz:pre_generation/step/pointer/update/z

execute if score Z ozPG >= Diameter ozPG run function oz:pre_generation/step/pointer/reset

#
# Start a pre-generation stage
#

# Zero out X and Z
scoreboard players set X ozPG 0
scoreboard players set Z ozPG 0

# Set the initial direction to positive
scoreboard players set Direction ozPG 1

# Calculate the diameter to generate
scoreboard players set Eight ozPG 8
scoreboard players operation Diameter ozPG = OZ ozBSize
execute if score Dimension ozPG matches -1 run scoreboard players operation Diameter ozPG /= Eight ozPG
scoreboard players reset Eight ozPG

# Set the initial values of done and total
scoreboard players set Done ozPG 0
scoreboard players operation Total ozPG = Diameter ozPG
scoreboard players set ChunkSize ozPG 16
scoreboard players operation Total ozPG /= ChunkSize ozPG
scoreboard players reset ChunkSize ozPG
scoreboard players operation Total ozPG *= Total ozPG

# Initialize the bossbar
execute store result bossbar oz:pregen max run scoreboard players get Total ozPG
bossbar set oz:pregen players @a
bossbar set oz:pregen value 0
bossbar set oz:pregen visible true

# Calculate the BaseX and BaseZ coordinates
function oz:pre_generation/stage/calculate_base

# Load the origin chunk for which markers are summoned
execute positioned as @e[type=minecraft:armor_stand,tag=lobbycenter,limit=1] run function oz:pre_generation/stage/load_origin

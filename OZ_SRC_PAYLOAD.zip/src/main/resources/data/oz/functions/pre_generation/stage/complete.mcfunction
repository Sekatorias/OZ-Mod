#
# Complete the current stage of the pre-generation
#

bossbar set oz:pregen visible false

execute if score AlreadyLoadedOrigin ozPG matches 0 positioned as @e[type=minecraft:armor_stand,tag=lobbycenter,limit=1] run function oz:pre_generation/stage/unload_origin

scoreboard players reset AlreadyLoaded ozPG
scoreboard players reset AlreadyLoadedOrigin ozPG
scoreboard players reset X ozPG
scoreboard players reset Y ozPG
scoreboard players reset Done ozPG
scoreboard players reset Total ozPG
scoreboard players reset LoadTime ozPG
scoreboard players reset Direction ozPG

scoreboard players reset * ozPGQueue

function oz:pre_generation/stage/next

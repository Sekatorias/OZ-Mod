#
# Select the next state of the pre-generation
#

scoreboard players add Stage ozPG 1

# Generate overworld
execute if score Stage ozPG matches 1 run scoreboard players set Dimension ozPG 0
execute if score Stage ozPG matches 1 run scoreboard players set LoadTime ozPG 30
execute if score Stage ozPG matches 1 run bossbar set oz:pregen name {"text":"OZ | Генерация обычного мира","color":"light_purple"}
# Generate nether (load it for longer to let lava flow)
execute if score Stage ozPG matches 2 run scoreboard players set Dimension ozPG -1
execute if score Stage ozPG matches 2 run scoreboard players set LoadTime ozPG 300
execute if score Stage ozPG matches 2 run bossbar set oz:pregen name {"text":"OZ | Генерация Незера","color":"light_purple"}

execute if score Stage ozPG matches ..2 run function oz:pre_generation/stage/start
execute unless score Stage ozPG matches ..2 run function oz:pre_generation/complete

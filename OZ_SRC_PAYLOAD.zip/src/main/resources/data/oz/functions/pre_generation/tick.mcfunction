#
# Tick the pre-generation, tail recursing on next tick if the stages are not yet complete
#

execute as @e[type=minecraft:marker,tag=pre_generator] run execute if score @s ozPGQueue >= LoadTime ozPG run function oz:pre_generation/step/complete
execute as @e[type=minecraft:marker,tag=pre_generator] run scoreboard players add @s ozPGQueue 1

execute if score X ozPG matches 0.. if score Z ozPG matches 0.. run function oz:pre_generation/step/start

# Check exit condition
# If the test fails, mark this step as done and continue
execute if entity @e[type=minecraft:marker,tag=pre_generator] run scoreboard players set NextStageDelay ozPG 0
execute unless entity @e[type=minecraft:marker,tag=pre_generator] run scoreboard players add NextStageDelay ozPG 1
execute if score NextStageDelay ozPG matches 20.. run function oz:pre_generation/stage/complete
execute if score NextStageDelay ozPG matches 20.. run scoreboard players set NextStageDelay ozPG 0
execute if score Stage ozPG matches ..2 run schedule function oz:pre_generation/tick 1t

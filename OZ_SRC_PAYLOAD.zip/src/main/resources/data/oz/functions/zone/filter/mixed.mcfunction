scoreboard players set ZFilter ozZone 3
data modify storage oz:text Zone.Name set value "{\"text\":\"Смешанная\",\"color\":\"light_purple\",\"bold\":true}"
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Фильтр зоны: ","color":"gray"},{"text":"Не менее 5 водных и 5 горных точек из 25","color":"aqua"}]

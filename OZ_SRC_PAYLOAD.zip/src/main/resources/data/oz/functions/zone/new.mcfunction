# OZ mod: Java arena search. Biomes are sampled from BiomeSource without loading/generating candidate chunks.
execute unless score OZ ozState matches 0..1 run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Нельзя менять зону во время активного матча.","color":"red"}]
execute if score OZ ozState matches 0..1 run oz zone search

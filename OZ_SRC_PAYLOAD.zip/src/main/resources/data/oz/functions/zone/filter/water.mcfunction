scoreboard players set ZFilter ozZone 1
data modify storage oz:text Zone.Name set value "{\"text\":\"Вода >=30%\",\"color\":\"aqua\",\"bold\":true}"
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Фильтр зоны: ","color":"gray"},{"text":"Океан/реки не менее чем в 8 из 25 точек","color":"aqua"}]

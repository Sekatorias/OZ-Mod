scoreboard players set ZFilter ozZone 0
data modify storage oz:text Zone.Name set value "{\"text\":\"Любая\",\"color\":\"green\",\"bold\":true}"
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Фильтр зоны: ","color":"gray"},{"text":"Любая новая зона","color":"aqua"}]

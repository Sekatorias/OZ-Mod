# OZ mod: reset persisted arena grid origin to the command executor's current position.
oz zone origin reset

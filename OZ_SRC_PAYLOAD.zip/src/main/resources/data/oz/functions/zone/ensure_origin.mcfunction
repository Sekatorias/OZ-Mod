# OZ mod: origin is persisted by Java; no marker and no permanently force-loaded chunk.
oz zone origin ensure

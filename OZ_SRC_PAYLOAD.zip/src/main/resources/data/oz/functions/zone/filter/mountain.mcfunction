scoreboard players set ZFilter ozZone 2
data modify storage oz:text Zone.Name set value "{\"text\":\"Горы >=30%\",\"color\":\"gold\",\"bold\":true}"
tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Фильтр зоны: ","color":"gray"},{"text":"Горные биомы не менее чем в 8 из 25 точек","color":"aqua"}]

# OZ mod: cancellation cannot leave forced chunks behind because search never creates them.
oz zone cancel silent

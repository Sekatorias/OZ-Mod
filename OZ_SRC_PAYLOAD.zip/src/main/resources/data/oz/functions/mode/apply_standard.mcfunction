scoreboard players set OZMode ozEnabled 1
scoreboard players set OZRespawns ozEnabled 1
scoreboard players set OZNaturalRegen ozEnabled 1
function oz:mode/display_standard

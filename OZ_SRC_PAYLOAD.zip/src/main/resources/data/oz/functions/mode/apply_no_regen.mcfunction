scoreboard players set OZMode ozEnabled 3
scoreboard players set OZRespawns ozEnabled 0
scoreboard players set OZNaturalRegen ozEnabled 0
function oz:mode/display_no_regen

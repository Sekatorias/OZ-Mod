execute if score OZ ozState matches 1 run function oz:mode/apply_standard
execute if score OZ ozState matches 1 as @a run function oz:lobby/reset_book
execute if score OZ ozState matches 1 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Режим: ","color":"gray"},{"text":"Стандарт: респавны до финала, регенерация включена","color":"green"}]
execute unless score OZ ozState matches 1 run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Режим можно менять только в лобби","color":"red"}]

function oz:mode/standard

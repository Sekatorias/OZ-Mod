function oz:mode/no_regen

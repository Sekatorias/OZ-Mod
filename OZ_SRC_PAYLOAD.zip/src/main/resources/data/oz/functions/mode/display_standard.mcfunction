data modify storage oz:text Mode.Name set value "{\"text\": \"Стандарт OZ\", \"color\": \"green\", \"bold\": true}"
data modify storage oz:text Mode.Start set value "{\"text\": \"Респавны до финала\", \"color\": \"gray\"}"

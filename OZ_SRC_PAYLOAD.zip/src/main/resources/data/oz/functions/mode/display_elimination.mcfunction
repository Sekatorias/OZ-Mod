data modify storage oz:text Mode.Name set value "{\"text\": \"Выбывание\", \"color\": \"gold\", \"bold\": true}"
data modify storage oz:text Mode.Start set value "{\"text\": \"Одна жизнь\", \"color\": \"gold\"}"

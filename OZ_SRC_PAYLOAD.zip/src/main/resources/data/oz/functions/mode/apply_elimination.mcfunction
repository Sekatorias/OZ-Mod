scoreboard players set OZMode ozEnabled 2
scoreboard players set OZRespawns ozEnabled 0
scoreboard players set OZNaturalRegen ozEnabled 1
function oz:mode/display_elimination

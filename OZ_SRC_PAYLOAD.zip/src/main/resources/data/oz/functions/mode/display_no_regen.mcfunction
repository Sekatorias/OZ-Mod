data modify storage oz:text Mode.Name set value "{\"text\": \"Без регенерации\", \"color\": \"red\", \"bold\": true}"
data modify storage oz:text Mode.Start set value "{\"text\": \"Одна жизнь, без регенерации\", \"color\": \"red\"}"

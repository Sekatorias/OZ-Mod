execute if score OZ ozState matches 1 run function oz:mode/apply_no_regen
execute if score OZ ozState matches 1 as @a run function oz:lobby/reset_book
execute if score OZ ozState matches 1 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Режим: ","color":"gray"},{"text":"Без регенерации: одна жизнь, естественная регенерация выключена","color":"red"}]
execute unless score OZ ozState matches 1 run tellraw @s [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Режим можно менять только в лобби","color":"red"}]

#
# Create all teams
# 
# Tag: #minecraft:load
#

team add spectate "Наблюдатели"
team modify spectate color black
team modify spectate deathMessageVisibility never

team add redstone "Красные"
team modify redstone color red

team add gold "Золотые"
team modify gold color yellow

team add slime "Лаймовые"
team modify slime color green

team add diamond "Алмазные"
team modify diamond color aqua

team add water "Синие"
team modify water color blue

team add purpur "Пурпурные"
team modify purpur color light_purple

team add stone "Серые"
team modify stone color gray

team add netherwart "Бордовые"
team modify netherwart color dark_red

team add acacia "Оранжевые"
team modify acacia color gold

team add grass "Тёмно-зелёные"
team modify grass color dark_green

team add prismarine "Призмариновые"
team modify prismarine color dark_aqua

team add lapis "Лазуритовые"
team modify lapis color dark_blue

team add chorus "Хорусовые"
team modify chorus color dark_purple

team add bedrock "Чёрные"
team modify bedrock color dark_gray

# Paper fix. Empty teams are deleted by default and as a result will not have the correct friendly fire option
execute if score OZ ozState matches 4 if score OZFriendlyFire ozEnabled matches 1 run function oz:starting/friendlyfire_enable
execute if score OZ ozState matches 4 if score OZFriendlyFire ozEnabled matches 0 run function oz:starting/friendlyfire_disable

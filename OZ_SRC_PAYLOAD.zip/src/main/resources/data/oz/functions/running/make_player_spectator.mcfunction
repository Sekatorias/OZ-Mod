#
# Mark the player as a spectator
#
# Entity: The player
#

effect clear @s[tag=oz_glow_managed] minecraft:glowing
tag @s remove oz_glow_managed
gamemode spectator @s
tag @s add spectator
effect give @s minecraft:night_vision 1000000 0 true

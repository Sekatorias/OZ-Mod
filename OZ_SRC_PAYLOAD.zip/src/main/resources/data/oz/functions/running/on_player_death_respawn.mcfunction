# Смерть до финальной стадии не выбивает участника.
# Если именно эта смерть запустила финал, она всё равно считается респавн-смертью:
# состояние респавна было сохранено до обработки Death Pressure.
scoreboard players reset @s ozDeaths
execute if score OZFinalActive ozEnabled matches 0 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" погиб — респавн ещё доступен","color":"gray"}]
execute if score OZFinalActive ozEnabled matches 1 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"selector":"@s","color":"aqua"},{"text":" погиб — эта смерть ещё допускает респавн, но финальная стадия уже началась","color":"gold"}]

#
# Replace the strong potion in the players inventory if
# the game state is running and strong potions are disabled
#
# Entity: The player who just obtained strong potion
#

advancement revoke @s only oz:running/obtain_strong_potion

execute if score OZ ozState matches 4 if score OZPotions ozEnabled matches 0 run function oz:running/strong_potions/replace

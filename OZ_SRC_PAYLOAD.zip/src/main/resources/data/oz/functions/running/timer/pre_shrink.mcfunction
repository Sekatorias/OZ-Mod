scoreboard players operation TSeconds ozTimer = OZFinalAt ozPressure
scoreboard players operation TSeconds ozTimer -= OZ ozMatchTick
execute if score TSeconds ozTimer matches ..-1 run scoreboard players set TSeconds ozTimer 0
scoreboard players operation TValue ozTimer = TSeconds ozTimer
scoreboard players operation TValue ozTimer *= #1000 ozTimer
scoreboard players operation TMax ozTimer = OZBaseFinalAt ozPressure
execute if score TMax ozTimer matches ..0 run scoreboard players set TMax ozTimer 1
scoreboard players operation TValue ozTimer /= TMax ozTimer
execute if score TValue ozTimer matches 1001.. run scoreboard players set TValue ozTimer 1000
execute store result bossbar oz:timer value run scoreboard players get TValue ozTimer
scoreboard players operation TSeconds ozTimer /= #20 ozTimer
scoreboard players operation TMinutes ozTimer = TSeconds ozTimer
scoreboard players operation TMinutes ozTimer /= #60 ozTimer
scoreboard players operation TRemain ozTimer = TSeconds ozTimer
scoreboard players operation TRemain ozTimer %= #60 ozTimer
execute if score TRemain ozTimer matches ..9 run function oz:running/timer/name_pre_short
execute if score TRemain ozTimer matches 10.. run function oz:running/timer/name_pre

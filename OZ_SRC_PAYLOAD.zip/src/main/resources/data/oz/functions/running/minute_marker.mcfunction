#
# Check if a minute marker is due to go off this minute
#
# Tag: #oz:minute
#

execute if score OZMarkers ozEnabled matches 1 if score OZ ozMin = OZ ozNextMM if score OZ ozMin matches 1.. run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Прошло ","color":"gray"},{"score":{"name":"OZ","objective":"ozNextMM"},"color":"gold"},{"text":" мин.","color":"gray"}]
execute if score OZMarkers ozEnabled matches 1 if score OZ ozMin = OZ ozNextMM if score OZ ozMin matches 1.. as @a at @s run playsound entity.firework_rocket.launch voice @s ~ ~ ~ 1 .5 1
execute if score OZMarkers ozEnabled matches 1 if score OZ ozMin = OZ ozNextMM run scoreboard players operation OZ ozNextMM += OZ ozMM

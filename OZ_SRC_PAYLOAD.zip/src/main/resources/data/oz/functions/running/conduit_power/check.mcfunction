#
# Reapply conduit power if it is enabled
#
# Tag: #oz:minute
#

execute if score OZConduit ozEnabled matches 1 run effect give @a[team=!spectate] minecraft:conduit_power 90 0 true

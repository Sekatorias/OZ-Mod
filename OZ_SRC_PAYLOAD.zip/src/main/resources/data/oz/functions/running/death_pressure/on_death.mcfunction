# If final phase was already active before this death, it accelerates the border.
execute if score OZ ozPressure matches 1.. if score OZFinalActive ozEnabled matches 1 run function oz:running/death_pressure/final_death
# Before final phase, only the first death of each player affects the deadline.
# This is intentionally evaluated second: if pre_death itself launches the final,
# the same death is NOT counted again as a final-phase acceleration event.
execute if score OZ ozPressure matches 1.. if score OZFinalActive ozEnabled matches 0 unless score @s ozPressure matches 1.. run function oz:running/death_pressure/pre_death

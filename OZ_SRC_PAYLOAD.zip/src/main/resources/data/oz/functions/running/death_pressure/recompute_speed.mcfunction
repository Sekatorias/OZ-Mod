scoreboard players operation OZSpeedPct ozPressure = OZEvents ozPressure
scoreboard players operation OZSpeedPct ozPressure *= OZ ozPressure
scoreboard players operation OZSpeedPct ozPressure /= OZPlayers ozPressure
scoreboard players add OZSpeedPct ozPressure 100
execute if score OZSpeedPct ozPressure matches 251.. run scoreboard players set OZSpeedPct ozPressure 250
scoreboard players operation OZSpeedTier ozPressure = OZSpeedPct ozPressure

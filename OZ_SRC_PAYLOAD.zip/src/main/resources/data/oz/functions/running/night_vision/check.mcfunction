#
# Reapply night vision if it is enabled
#
# Tag: #oz:minute
#

execute if score OZNightVision ozEnabled matches 1 run effect give @a[team=!spectate] minecraft:night_vision 90 0 true

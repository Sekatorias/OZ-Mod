# OZ v10 dynamic shrink. Speed is recalculated from Death Pressure.
execute if score OZFinalActive ozEnabled matches 0 run function oz:running/final_stage/activate
scoreboard players set OZBorderDone ozEnabled 0
scoreboard players set OZShrinkTick ozPressure 0
function oz:running/border_shrinking/step
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Граница начала сужаться. Скорость: ","color":"gold"},{"score":{"name":"OZSpeedPct","objective":"ozPressure"},"color":"yellow"},{"text":"%","color":"gray"}]

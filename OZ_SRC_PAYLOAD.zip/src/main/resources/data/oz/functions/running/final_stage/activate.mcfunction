execute if score OZFinalActive ozEnabled matches 0 run scoreboard players set OZFinalActive ozEnabled 1
scoreboard players set OZRespawns ozEnabled 0
title @a title {"text":"ФИНАЛЬНАЯ СТАДИЯ","color":"red","bold":true}
title @a subtitle {"text":"Каждая смерть окончательна","color":"gold"}
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Финал: ","color":"red","bold":true},{"text":"респавны отключены","color":"gold"}]
execute as @a at @s run playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 1 0

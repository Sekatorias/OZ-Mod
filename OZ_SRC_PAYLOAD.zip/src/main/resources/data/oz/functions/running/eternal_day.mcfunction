#
# Check whether eternal day should start this minute
#
# Tag: #oz:minute
#

execute if score OZEternal ozEnabled matches 1 if score OZ ozMin = OZ ozEternal run gamerule doDaylightCycle false
execute if score OZEternal ozEnabled matches 1 if score OZ ozMin = OZ ozEternal run time set noon
execute if score OZEternal ozEnabled matches 1 if score OZ ozMin = OZ ozEternal run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Наступил вечный день","color":"gold"}]
execute if score OZEternal ozEnabled matches 1 if score OZ ozMin = OZ ozEternal as @a at @s run playsound minecraft:entity.wither.spawn player @s ~ ~ ~ 1 1.5

#
# Replace all the strong potions from the player's inventory and notify the player
#
# Entity: The player
# Location: The location of the player
#

tag @s remove any_strong_potion

function oz:running/strong_potions/replace_loop

playsound minecraft:entity.witch.drink player @s[tag=any_strong_potion] ~ ~ ~ 1 0.9
tellraw @s[tag=any_strong_potion] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Зелья II уровня отключены","color":"red"}]
tag @s remove any_strong_potion


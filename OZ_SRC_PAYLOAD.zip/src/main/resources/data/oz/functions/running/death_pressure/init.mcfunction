# Capture the initial field once. All fractions are based on this number.
scoreboard players set OZPlayers ozPressure 0
execute as @a[tag=playing] run scoreboard players add OZPlayers ozPressure 1
execute if score OZPlayers ozPressure matches ..0 run scoreboard players set OZPlayers ozPressure 1
scoreboard players set OZEvents ozPressure 0
scoreboard players set OZSpeedPct ozPressure 100
scoreboard players set OZSpeedTier ozPressure 100
scoreboard players set OZFinalActive ozEnabled 0
scoreboard players set OZBorderDone ozEnabled 0
scoreboard players set OZShrinkTick ozPressure 0
scoreboard players set OZ ozMatchTick 0
scoreboard players set @a ozPressure 0

# Planned shrink start in ticks.
scoreboard players operation OZFinalAt ozPressure = OZ ozSBStart
scoreboard players operation OZFinalAt ozPressure *= #1200 ozPressure
scoreboard players operation OZBaseFinalAt ozPressure = OZFinalAt ozPressure
scoreboard players operation OZCutTicks ozPressure = OZFinalAt ozPressure
scoreboard players operation OZCutTicks ozPressure *= OZ ozPressure
scoreboard players operation OZCutTicks ozPressure /= #100 ozPressure
scoreboard players operation OZCutTicks ozPressure /= OZPlayers ozPressure
scoreboard players operation OZCutSec ozPressure = OZCutTicks ozPressure
scoreboard players operation OZCutSec ozPressure /= #20 ozPressure

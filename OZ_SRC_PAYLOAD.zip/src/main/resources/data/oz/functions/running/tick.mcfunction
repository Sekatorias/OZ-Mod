#
# Run all the things which need to happen on every tick while the game is running
#

# Handle players who have died or joined the game after it as started
team join spectate @a[gamemode=survival,tag=!playing,team=]
execute as @a[tag=playing,scores={ozDeaths=1..}] run function #oz:events/on_player_death
# We don't use make_player_spectator immediately to handle a player dying correctly.
# We need them to have respawned before we apply night vision to them
execute as @a[gamemode=survival,tag=!playing] run gamemode spectator @s
execute as @a[gamemode=spectator,tag=!spectator,scores={ozAliveTime=1..}] run function oz:running/make_player_spectator

# OZ v10 dynamic match timer / border speed
function oz:running/death_pressure/tick

# Intermittent final reveal: 10 seconds at the start of every minute.
function oz:running/glowing/pulse_tick

execute if score OZ ozTick matches 1200 run scoreboard players add OZ ozMin 1
execute if score OZ ozTick matches 1200.. run scoreboard players set OZ ozTick 0
execute if score OZ ozTick matches 0 run function #oz:minute

execute as @a[scores={ozDiaChest=1..}] run function oz:running/diamond_chestplate/cleanup


# Final-phase center beacon pulse (20 ticks = once per second)
scoreboard players add OZ ozFxTick 1
execute if score OZ ozFxTick matches 20.. run function oz:running/center/pulse
execute if score OZ ozFxTick matches 20.. run function oz:running/timer/update
execute if score OZ ozFxTick matches 20.. run scoreboard players set OZ ozFxTick 0

execute store result score TBorderNow ozTimer run worldborder get
scoreboard players operation TDistance ozTimer = TBorderNow ozTimer
scoreboard players operation TDistance ozTimer -= OZ ozSBSize
execute if score TDistance ozTimer matches ..0 run scoreboard players set TDistance ozTimer 0
scoreboard players operation TBaseDist ozTimer = OZ ozBSize
scoreboard players operation TBaseDist ozTimer -= OZ ozSBSize
execute if score TBaseDist ozTimer matches ..0 run scoreboard players set TBaseDist ozTimer 1
# Progress bar follows remaining border distance.
scoreboard players operation TValue ozTimer = TDistance ozTimer
scoreboard players operation TValue ozTimer *= #1000 ozTimer
scoreboard players operation TValue ozTimer /= TBaseDist ozTimer
execute if score TValue ozTimer matches 1001.. run scoreboard players set TValue ozTimer 1000
execute store result bossbar oz:timer value run scoreboard players get TValue ozTimer
# Approximate remaining seconds at the currently selected Death Pressure speed.
scoreboard players operation TNum ozTimer = TDistance ozTimer
scoreboard players operation TNum ozTimer *= OZ ozSBDur
scoreboard players operation TNum ozTimer *= #60 ozTimer
scoreboard players operation TNum ozTimer *= #100 ozTimer
scoreboard players operation TDen ozTimer = TBaseDist ozTimer
scoreboard players operation TDen ozTimer *= OZSpeedPct ozPressure
execute if score TDen ozTimer matches ..0 run scoreboard players set TDen ozTimer 1
scoreboard players operation TSeconds ozTimer = TNum ozTimer
scoreboard players operation TSeconds ozTimer /= TDen ozTimer
scoreboard players operation TMinutes ozTimer = TSeconds ozTimer
scoreboard players operation TMinutes ozTimer /= #60 ozTimer
scoreboard players operation TRemain ozTimer = TSeconds ozTimer
scoreboard players operation TRemain ozTimer %= #60 ozTimer
execute if score TRemain ozTimer matches ..9 run function oz:running/timer/name_shrink_short
execute if score TRemain ozTimer matches 10.. run function oz:running/timer/name_shrink

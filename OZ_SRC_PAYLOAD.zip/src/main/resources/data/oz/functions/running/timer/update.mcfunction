# OZ v10.3 persistent match timer.
execute if score OZFinalActive ozEnabled matches 0 run function oz:running/timer/pre_shrink
execute if score OZFinalActive ozEnabled matches 1 if score OZShrink ozEnabled matches 1 if score OZBorderDone ozEnabled matches 0 run function oz:running/timer/shrinking
execute if score OZFinalActive ozEnabled matches 1 if score OZShrink ozEnabled matches 1 if score OZBorderDone ozEnabled matches 1 run function oz:running/timer/done
execute if score OZFinalActive ozEnabled matches 1 if score OZShrink ozEnabled matches 0 run function oz:running/timer/final_only

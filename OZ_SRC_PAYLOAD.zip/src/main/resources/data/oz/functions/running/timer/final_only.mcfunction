bossbar set oz:timer value 0
bossbar set oz:timer name {"text":"OZ | Финальная фаза","color":"red","bold":true}

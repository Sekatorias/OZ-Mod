#
# Disable the AI for any passive mobs. Runs once a minute
#
# Tag: #oz:minute
#

execute if score OZPassiveAI ozEnabled matches 0 run execute as @e[type=#oz:passive,type=!#oz:combat_tameable] unless data entity @s Passenger[0] run data merge entity @s {NoAI:1b}

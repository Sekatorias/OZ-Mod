# Announcements for the configured pulse-glow window.
# Actual glow is handled every tick by glowing/pulse_tick.

execute if score OZGlow ozEnabled matches 1 if score OZ ozMin = OZ ozGlow run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Импульсная подсветка активна","color":"gold"},{"text":" • 10 сек. каждую минуту","color":"gray"}]
execute if score OZGlow ozEnabled matches 1 if score OZ ozMin = OZ ozGlow as @a at @s run playsound minecraft:entity.evoker.cast_spell player @s ~ ~ ~ 0.8 1.25

execute if score OZGlow ozEnabled matches 1 if score OZ ozMin = OZ ozGlowEnd run effect clear @a[tag=oz_glow_managed] minecraft:glowing
execute if score OZGlow ozEnabled matches 1 if score OZ ozMin = OZ ozGlowEnd run tag @a[tag=oz_glow_managed] remove oz_glow_managed
execute if score OZGlow ozEnabled matches 1 if score OZ ozMin = OZ ozGlowEnd run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Импульсная подсветка отключена","color":"gray"}]

#
# Check the playing players remaining and see if they are all on the same team
#
# Tag: #oz:events/on_player_death
#

# Special case. Each player without a team are treated as separate teams
execute store result score TeamsRemaining ozState run execute if entity @a[tag=playing,team=]

execute if entity @a[tag=playing,team=redstone] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=gold] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=slime] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=diamond] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=water] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=purpur] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=stone] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=netherwart] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=acacia] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=grass] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=prismarine] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=lapis] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=chorus] run scoreboard players add TeamsRemaining ozState 1
execute if entity @a[tag=playing,team=bedrock] run scoreboard players add TeamsRemaining ozState 1

execute if score TeamsRemaining ozState matches 0..1 run tellraw @a[tag=admin] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Победитель определён ","color":"gold"},{"text":"[ЗАВЕРШИТЬ МАТЧ]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/function oz:complete"},"hoverEvent":{"action":"show_text","value":"Зафиксировать результат и показать итоги"}}]

#
# Replace the suspcious stew in the players inventory
# if the game state is running and suspicious stews are disabled
#
# Entity: The player who just obtained suspicious stew
#

advancement revoke @s only oz:running/obtain_suspicious_stew

execute if score OZ ozState matches 4 if score OZStew ozEnabled matches 0 run function oz:running/suspicious_stew/replace

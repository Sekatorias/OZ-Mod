# Pulse glow is refreshed directly every tick while the 10-second reveal pulse
# is active. No delayed area-effect cloud is needed; outside the pulse, milk
# must not accidentally restore Glowing.

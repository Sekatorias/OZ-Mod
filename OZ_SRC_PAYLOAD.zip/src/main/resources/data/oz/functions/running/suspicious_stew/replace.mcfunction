#
# Replace the suspicious stew from the player's inventory
#
# Entity: The player
# Location: The location of the player
#

tag @s remove suspicious_stew

# There is a race condition between the player acquiring the suspicious stew
# and the invocation of this function. As a result, we need to double check
# The player indeed has suspicious stew
execute store success score @s ozPotion run clear @s minecraft:suspicious_stew 1
execute if score @s ozPotion matches 1 run give @s minecraft:mushroom_stew
execute if score @s ozPotion matches 1 run tag @s add suspicious_stew

playsound minecraft:entity.player.burp player @s[tag=suspicious_stew] ~ ~ ~ 1 0.9
tellraw @s[tag=suspicious_stew] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Подозрительный суп отключён","color":"red"}]
tag @s remove suspicious_stew


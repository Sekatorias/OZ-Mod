# v10: shrink timing is tick-based in oz:running/death_pressure/tick.

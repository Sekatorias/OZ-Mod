# Highly visible purple beacon at the exact X/Z center of the arena.
# The arena-center marker sits at Y=64. Seven overlapping vertical particle
# sections form a thick column from roughly Y=0 to the build limit.
# This is particles only: no visible entity and no terrain changes.

# Purple outer column (large dust particles)
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ -48 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 0 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 48 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 96 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 144 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 192 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 240 ~ run particle minecraft:dust 0.68 0.08 1.0 4 ~ ~ ~ 0.85 30 0.85 0 42 force @a

# Bright white/purple core to make the column readable against sky, caves and fog.
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ -48 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 0 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 48 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 96 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 144 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 192 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a
execute if score OZCenter ozEnabled matches 1 if score OZ ozMin >= OZ ozCenterStart if score OZ ozMin < OZ ozCenterEnd at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] positioned ~ 240 ~ run particle minecraft:end_rod ~ ~ ~ 0.28 30 0.28 0.002 10 force @a

# OZ pulse glow: during the configured glow window, living participants are
# revealed for the first 10 seconds (200 ticks) of every minute.

# ON pulse: refresh a very short effect every tick. Drinking milk therefore only
# hides the outline until the next tick while the reveal pulse is active.
execute if score OZGlow ozEnabled matches 1 if score OZ ozMin >= OZ ozGlow if score OZ ozMin < OZ ozGlowEnd if score OZ ozTick matches 0..199 run effect give @a[tag=playing,team=!spectate,gamemode=!spectator] minecraft:glowing 1 0 true
execute if score OZGlow ozEnabled matches 1 if score OZ ozMin >= OZ ozGlow if score OZ ozMin < OZ ozGlowEnd if score OZ ozTick matches 0..199 run tag @a[tag=playing,team=!spectate,gamemode=!spectator] add oz_glow_managed

# OFF part of the minute: remove only glow that OZ marked as managed.
execute if score OZ ozTick matches 200.. run effect clear @a[tag=oz_glow_managed] minecraft:glowing
execute if score OZ ozTick matches 200.. run tag @a[tag=oz_glow_managed] remove oz_glow_managed

# Also clean up immediately if the feature is disabled or the configured window ends.
execute unless score OZGlow ozEnabled matches 1 run effect clear @a[tag=oz_glow_managed] minecraft:glowing
execute unless score OZGlow ozEnabled matches 1 run tag @a[tag=oz_glow_managed] remove oz_glow_managed
execute if score OZ ozMin < OZ ozGlow run effect clear @a[tag=oz_glow_managed] minecraft:glowing
execute if score OZ ozMin < OZ ozGlow run tag @a[tag=oz_glow_managed] remove oz_glow_managed
execute if score OZ ozMin >= OZ ozGlowEnd run effect clear @a[tag=oz_glow_managed] minecraft:glowing
execute if score OZ ozMin >= OZ ozGlowEnd run tag @a[tag=oz_glow_managed] remove oz_glow_managed

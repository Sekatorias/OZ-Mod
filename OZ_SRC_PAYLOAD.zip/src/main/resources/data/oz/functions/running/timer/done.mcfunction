bossbar set oz:timer value 0
bossbar set oz:timer name {"text":"OZ | Граница сжалась • финал","color":"red","bold":true}

scoreboard players set @s ozPressure 1
scoreboard players add OZEvents ozPressure 1
scoreboard players operation OZFinalAt ozPressure -= OZCutTicks ozPressure
execute if score OZFinalAt ozPressure < OZ ozMatchTick run scoreboard players operation OZFinalAt ozPressure = OZ ozMatchTick
function oz:running/death_pressure/recompute_speed
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Death Pressure: ","color":"red","bold":true},{"selector":"@s","color":"aqua"},{"text":" приблизил сужение на ","color":"gray"},{"score":{"name":"OZCutSec","objective":"ozPressure"},"color":"gold"},{"text":" сек. Скорость: ","color":"gray"},{"score":{"name":"OZSpeedPct","objective":"ozPressure"},"color":"gold"},{"text":"%","color":"gray"}]
execute if score OZ ozMatchTick >= OZFinalAt ozPressure if score OZShrink ozEnabled matches 1 run function oz:running/border_shrinking/activate
execute if score OZ ozMatchTick >= OZFinalAt ozPressure if score OZShrink ozEnabled matches 0 run function oz:running/final_stage/activate

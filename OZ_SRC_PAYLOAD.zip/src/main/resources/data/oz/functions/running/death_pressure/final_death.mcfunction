scoreboard players add OZEvents ozPressure 1
function oz:running/death_pressure/recompute_speed
execute if score OZShrink ozEnabled matches 1 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Death Pressure: ","color":"red","bold":true},{"text":"следующий сегмент границы: ","color":"gray"},{"score":{"name":"OZSpeedPct","objective":"ozPressure"},"color":"gold"},{"text":"%","color":"gray"}]
execute if score OZShrink ozEnabled matches 0 run tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Death Pressure вырос, но сужение отключено","color":"gray"}]

scoreboard players add OZ ozMatchTick 1
# Start final phase at the dynamic deadline.
execute if score OZFinalActive ozEnabled matches 0 if score OZ ozMatchTick >= OZFinalAt ozPressure if score OZShrink ozEnabled matches 1 run function oz:running/border_shrinking/activate
execute if score OZFinalActive ozEnabled matches 0 if score OZ ozMatchTick >= OZFinalAt ozPressure if score OZShrink ozEnabled matches 0 run function oz:running/final_stage/activate

# Dynamic border speed: refresh one smooth minute segment. New pressure applies on the next segment.
execute if score OZFinalActive ozEnabled matches 1 if score OZShrink ozEnabled matches 1 if score OZBorderDone ozEnabled matches 0 run scoreboard players add OZShrinkTick ozPressure 1
execute if score OZShrinkTick ozPressure matches 1200.. if score OZFinalActive ozEnabled matches 1 if score OZShrink ozEnabled matches 1 if score OZBorderDone ozEnabled matches 0 run function oz:running/border_shrinking/step
execute if score OZShrinkTick ozPressure matches 1200.. run scoreboard players set OZShrinkTick ozPressure 0

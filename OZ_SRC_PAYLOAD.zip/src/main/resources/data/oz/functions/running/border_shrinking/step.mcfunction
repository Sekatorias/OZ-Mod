# OZ mod: Java computes the exact remaining duration; no generated lookup tree is needed.
oz border refresh

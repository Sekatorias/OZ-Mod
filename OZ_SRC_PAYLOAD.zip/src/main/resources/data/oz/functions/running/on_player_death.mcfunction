# Snapshot whether THIS death happened while respawns were still allowed.
tag @s remove oz_death_respawnable
execute if score OZRespawns ozEnabled matches 1 run tag @s add oz_death_respawnable

# Death Pressure may start the final phase, but the triggering death still follows the old rule.
function oz:running/death_pressure/on_death

execute if entity @s[tag=oz_death_respawnable] run function oz:running/on_player_death_respawn
execute unless entity @s[tag=oz_death_respawnable] run function oz:running/mark_player_dead
execute unless entity @s[tag=oz_death_respawnable] run function oz:running/check_for_victory
execute unless entity @s[tag=oz_death_respawnable] run function oz:awards/check_early_exit
execute unless entity @s[tag=oz_death_respawnable] run function oz:awards/check_first_blood
tag @s remove oz_death_respawnable

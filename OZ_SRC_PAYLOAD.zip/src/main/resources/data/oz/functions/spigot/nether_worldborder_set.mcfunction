#
# Set the center of the nether worldborder to the location of oz:dynamic_tp Pos
#
# Entity: @e[type=minecraft:armor_stand,tag=nethercenter]
# Location: In the nether
#

data modify entity @s Pos set from storage oz:dynamic_tp Pos

tellraw @a[tag=admin] [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Центр границы Незера синхронизирован","color":"gray"}]

execute at @s run worldborder center ~ ~
kill @s

# Алиас для /function oz:book
function oz:book

# Обратный отсчёт перед стартом
execute if score OZ ozTick matches 1 run title @a subtitle {"text":"Приготовьтесь","color":"gray"}
execute if score OZ ozTick matches 1 run title @a title {"text":"OZ НАЧИНАЕТСЯ","color":"light_purple","bold":true}
execute if score OZ ozTick matches 1 as @a at @s run playsound minecraft:entity.wither.spawn player @s ~ ~ ~ 1
execute if score OZ ozTick matches 60 run title @a subtitle ""
execute if score OZ ozTick matches 60 run title @a title {"text":"5","color":"gold"}
execute if score OZ ozTick matches 60 as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 0.5
execute if score OZ ozTick matches 80 run title @a title {"text":"4","color":"gold"}
execute if score OZ ozTick matches 80 as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 0.6
execute if score OZ ozTick matches 100 run title @a title {"text":"3","color":"gold"}
execute if score OZ ozTick matches 100 as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 0.7
execute if score OZ ozTick matches 120 run title @a title {"text":"2","color":"gold"}
execute if score OZ ozTick matches 120 as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 0.8
execute if score OZ ozTick matches 140 run title @a title {"text":"1","color":"gold"}
execute if score OZ ozTick matches 140 as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 0.9
execute if score OZ ozTick matches 160 run title @a subtitle {"storage":"oz:text","nbt":"Mode.Start","interpret":true}
execute if score OZ ozTick matches 160 run title @a title {"text":"В БОЙ!","color":"green","bold":true}
execute if score OZ ozTick matches 160.. run function oz:starting/start

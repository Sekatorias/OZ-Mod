# Global start kit selected by the OZ admin.
execute if score OZ ozKit matches 1 run give @s minecraft:wooden_sword 1
execute if score OZ ozKit matches 1 run give @s minecraft:wooden_pickaxe 1
execute if score OZ ozKit matches 1 run give @s minecraft:wooden_axe 1
execute if score OZ ozKit matches 1 run give @s minecraft:wooden_shovel 1
execute if score OZ ozKit matches 2 run give @s minecraft:stone_sword 1
execute if score OZ ozKit matches 2 run give @s minecraft:stone_pickaxe 1
execute if score OZ ozKit matches 2 run give @s minecraft:stone_axe 1
execute if score OZ ozKit matches 2 run give @s minecraft:stone_shovel 1

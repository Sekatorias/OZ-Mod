#
# Do all the things required to start the OZ
#

# Ensure that no sidebar is visible
scoreboard objectives setdisplay sidebar

# Clear the players inventory and effects
clear @a
effect clear @a
# Help people not accidentally die in the first 5 seconds
effect give @a minecraft:resistance 5 255 true
# This is the magic amount of hunger to set all players saturation to 5.0f
effect give @a minecraft:hunger 3 200 true

# Set the world border
execute if score OZ ozBSize matches 496 run worldborder set 496
execute if score OZ ozBSize matches 1008 run worldborder set 1008
execute if score OZ ozBSize matches 1520 run worldborder set 1520
execute if score OZ ozBSize matches 2032 run worldborder set 2032
execute if score OZ ozBSize matches 2544 run worldborder set 2544
execute if score OZ ozBSize matches 3056 run worldborder set 3056
# Fix for Spigot/Paper as world border is dimension specific. This is a noop on Vanilla
execute if score OZ ozBSize matches 496 in minecraft:the_nether run worldborder set 496
execute if score OZ ozBSize matches 1008 in minecraft:the_nether run worldborder set 1008
execute if score OZ ozBSize matches 1520 in minecraft:the_nether run worldborder set 1520
execute if score OZ ozBSize matches 2032 in minecraft:the_nether run worldborder set 2032
execute if score OZ ozBSize matches 2544 in minecraft:the_nether run worldborder set 2544
execute if score OZ ozBSize matches 3056 in minecraft:the_nether run worldborder set 3056

gamemode survival @a[team=!spectate]
execute as @a[team=spectate] run function oz:running/make_player_spectator

# Add the 'playing' tag for all players who are participating in the OZ
# This is important for the death function
tag @a[team=!spectate] add playing

# Optional starter tools selected in the lobby.
execute as @a[tag=playing] run function oz:starting/give_kit

# Spread the players based off the world size
execute if score OZ ozBSize matches 496 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 232 true @a[tag=playing]
execute if score OZ ozBSize matches 1008 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 488 true @a[tag=playing]
execute if score OZ ozBSize matches 1520 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 744 true @a[tag=playing]
execute if score OZ ozBSize matches 2032 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 1000 true @a[tag=playing]
execute if score OZ ozBSize matches 2544 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 1256 true @a[tag=playing]
execute if score OZ ozBSize matches 3056 at @e[type=minecraft:armor_stand,tag=lobbycenter] run spreadplayers ~ ~ 224 1512 true @a[tag=playing]

# OZ: respawn each player at their initial spread location
execute as @a[tag=playing] at @s run spawnpoint @s ~ ~ ~

# Ideally we would do this in the tick function like the other sounds,
# however if we do the player won't hear it because they will be immediately
# teleported away
execute as @a at @s run playsound minecraft:block.note_block.flute player @s ~ ~ ~ 1 1

# Persistent arena center used by the final-phase beacon.
# minecraft:marker has no client model, so it is never visible even in spectator.
execute as @e[type=minecraft:marker,tag=oz_arena_center] at @s run forceload remove ~ ~
kill @e[type=minecraft:marker,tag=oz_arena_center]
execute at @e[type=minecraft:armor_stand,tag=lobbycenter,limit=1] positioned ~ 64 ~ run summon minecraft:marker ~ ~ ~ {Tags:["oz_arena_center"]}
execute at @e[type=minecraft:marker,tag=oz_arena_center,limit=1] run forceload add ~ ~
execute as @e[type=minecraft:marker,tag=oz_arena_center,limit=1] store result score CenterX ozCoord run data get entity @s Pos[0] 1
execute as @e[type=minecraft:marker,tag=oz_arena_center,limit=1] store result score CenterZ ozCoord run data get entity @s Pos[2] 1
scoreboard players set OZ ozFxTick 0

# Clean up the lobby
execute at @e[type=minecraft:armor_stand,tag=lobbycenter] run fill ~-12 250 ~-12 ~11 289 ~11 minecraft:air
kill @e[tag=lobby]

# Правила матча OZ
difficulty hard
# spectatorsGenerateChunks=false is current broken in Minecraft, making chunks not render
gamerule spectatorsGenerateChunks true
# Apply natural regeneration from the selected mode
execute if score OZNaturalRegen ozEnabled matches 1 in minecraft:overworld run gamerule naturalRegeneration true
execute if score OZNaturalRegen ozEnabled matches 1 in minecraft:the_nether run gamerule naturalRegeneration true
execute if score OZNaturalRegen ozEnabled matches 1 in minecraft:the_end run gamerule naturalRegeneration true
execute if score OZNaturalRegen ozEnabled matches 0 in minecraft:overworld run gamerule naturalRegeneration false
execute if score OZNaturalRegen ozEnabled matches 0 in minecraft:the_nether run gamerule naturalRegeneration false
execute if score OZNaturalRegen ozEnabled matches 0 in minecraft:the_end run gamerule naturalRegeneration false
gamerule randomTickSpeed 3
gamerule doFireTick true
gamerule doDaylightCycle true
time set 0
weather clear 999999

# Set all customizable options
execute if score OZPhantoms ozEnabled matches 1 run gamerule doInsomnia true
execute if score OZPhantoms ozEnabled matches 0 run gamerule doInsomnia false

execute if score OZAdvancements ozEnabled matches 1 run gamerule announceAdvancements true
execute if score OZAdvancements ozEnabled matches 0 run gamerule announceAdvancements false

# Set Friendly Fire
execute if score OZFriendlyFire ozEnabled matches 1 run function oz:starting/friendlyfire_enable
execute if score OZFriendlyFire ozEnabled matches 0 run function oz:starting/friendlyfire_disable

# Reset all the relevant scoreboards and set state to running
scoreboard players reset @a ozDeaths
# Instead of resetting the values, we set them to 0 to ensure
# players with 0 damage dealt are taken into account for the
# Mostly Harmless award
scoreboard players set @a ozDmgDealt 0
scoreboard players reset @a ozDmgTaken
scoreboard players reset @a ozKills
scoreboard players set OZ ozMin 0
scoreboard players set OZ ozTick 0
function oz:running/death_pressure/init
bossbar set oz:timer players @a
bossbar set oz:timer visible true
function oz:running/timer/update
scoreboard players set OZ ozState 4
function #oz:events/on_start
function #oz:minute

# OZ v10: show the two time-control recipes in the recipe book.
recipe give @a[tag=playing] oz:time_back
recipe give @a[tag=playing] oz:time_forward

# OZ v9.1: force a fresh Origin choice once the match is fully started.
# Spectators are excluded because only participating players carry the playing tag.
origin gui @a[tag=playing,gamemode=survival] origins:origin

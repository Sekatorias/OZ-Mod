# Создать новое лобби OZ в текущих X/Z
# Выполняется игроком-оператором из центра будущей арены

function oz:reset_internal

# Новый раунд всегда начинается с нейтрального Origin.
# Игроки смогут выбрать/получить свой Origin уже после создания лобби.
origin set @a origins:origin origins:human

function oz:zone/ensure_origin

setworldspawn ~ 253 ~
worldborder center ~ ~
worldborder set 3056
execute in minecraft:the_nether store result score OZBorder ozPG run worldborder get
execute unless score OZBorder ozPG matches 3056 in minecraft:the_nether run function oz:spigot/nether_worldborder
scoreboard players reset OZBorder ozPG

fill ~-12 250 ~-12 ~11 289 ~11 minecraft:barrier hollow
fill ~-11 289 ~-11 ~10 289 ~10 minecraft:air
summon minecraft:armor_stand ~ 251 ~ {Tags:[lobby,lobbycenter],NoGravity:1b,Small:1b,Invisible:1b,CustomNameVisible:1b,CustomName:"[{\"text\":\"OZ | ЛОББИ\",\"color\":\"light_purple\",\"bold\":true}]"}
setblock ~ 251 ~ minecraft:structure_block{mode:"LOAD",name:"oz:lobby_armor_stands",ignoreEntities:0b,posX:-6,posZ:-6}
setblock ~ 252 ~ minecraft:redstone_block
# Remove the temporary loader blocks after lobby entities have been spawned.
setblock ~ 252 ~ minecraft:air
setblock ~ 251 ~ minecraft:air
# Parkour.litematic imported as a vanilla structure. Bottom platform is centered on spawn.
place template oz:parkour ~-6 251 ~-7

tag @s add admin
tp @a ~ 253 ~
gamemode adventure @a
execute as @a at @s run spawnpoint @s ~ ~ ~

difficulty peaceful
execute in minecraft:overworld run gamerule naturalRegeneration true
execute in minecraft:the_nether run gamerule naturalRegeneration true
execute in minecraft:the_end run gamerule naturalRegeneration true
gamerule randomTickSpeed 0
gamerule doFireTick false
gamerule doDaylightCycle false
time set noon
weather clear 999999

scoreboard players set OZ ozState 1
scoreboard objectives setdisplay sidebar ozLobby

# При обычном setup настройки матча сбрасываются.
# При автоматическом переносе зоны reset_options пропускается, остальные on_lobby hooks продолжают работать.
function #oz:events/on_lobby
execute if score ZAutoSetup ozZone matches 1 run scoreboard players set ZAutoSetup ozZone 0

title @a title {"text":"OZ","color":"light_purple","bold":true}
title @a subtitle {"text":"Лобби готово","color":"gray"}
tellraw @a [{"text":"[","color":"dark_purple"},{"text":"OZ","color":"light_purple","bold":true},{"text":"] ","color":"dark_purple"},{"text":"Лобби создано. Настройки находятся в книге","color":"gold"}]

#
# Begin the OZ starting sequence
#

scoreboard objectives setdisplay sidebar

scoreboard players set OZ ozState 3
scoreboard players set OZ ozTick 0

function #oz:events/on_starting
